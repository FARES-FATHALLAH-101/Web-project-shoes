import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAnglesRight } from '@fortawesome/free-solid-svg-icons'
import axios from "axios";
import { Home } from './components/home/index';
import Products from './components/Product/Products';
import Contact from './components/Contact/Contact';
import About from './components/Contact/About';
import Sproduct from './components/Product/Sproduct';
import AdminLayout from './admin/AdminLayout';
import Dashboard from './admin/Dashboard/Dashboard';
import Productsadmin from './admin/Products/Products';
import Orders from './admin/Orders/Orders';
import Addproducts from './admin/Products/Addproducts';
import Categories from './admin/Category/Category';
import Info from './admin/Setting/Info';
import Password from './admin/Setting/Password';
import SpecificSetting from './admin/Setting/SpecificSetting';
import Accounts from './admin/Setting/Accounts';
import AddAccounts from './admin/Setting/AddAccount';
import EditAdmin from './admin/Setting/EditAdmin';
import EditProduct from './admin/Products/EditProduct';
import HomeLayout from './components/HomeLayout';
import Profile from './components/login/Profile';
import Panier from './components/pannier/panier';

const ToTopButton = () => {
    const [isVisible, setIsVisible] = useState(false);

    const handleScroll = () => {
        setIsVisible(window.pageYOffset > 20);
    };

    const scrollToTop = () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    useEffect(() => {
        window.addEventListener('scroll', handleScroll);

        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    if (!isVisible)
        return null;

    return (
        <button
            onClick={scrollToTop}
            id="scrollButton"
            title="Go to top"
            style={{
                display: 'block',
                position: 'fixed',
                bottom: '60px',
                right: '60px',
                zIndex: '99',
                fontSize: '18px',
                border: '3px solid #0000ff47',
                outline: 'none',
                cursor: 'pointer',
                padding: '0px 18px',
                borderRadius: '51px',
                color: 'blue',
                transformOrigin: '100% 50%',
                transform: 'rotate(270deg) translate(50%)',
                background: '#ffffff00',
            }}
        >
            TO TOP   <FontAwesomeIcon icon={faAnglesRight} fade style={{ color: "blue", }} />
        </button>
    );
};
function App() {
    const [data, setData] = useState([]);

    const fetch = async () => {
        const res = await axios.get('http://127.0.0.1:8000/api/products')
        setData(res.data)
    }

    useEffect(() => {
        fetch();
    }, []);
    return (
        <Router>
            <Routes>
                <Route path="/" element={<HomeLayout />}>
                    <Route path="/" element={<Home />} />
                    <Route path="/products" element={<Products />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/detail/:idPrd" element={<Sproduct data={data} />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path='/panier' element={<Panier />}></Route>

                </Route>
                    {/* <ToTopButton/> */}
                <Route path="/admin" element={<AdminLayout />}>
                    <Route path="/admin" element={<Dashboard />} />
                    <Route path="products" element={<Productsadmin />} />
                    <Route path="order" element={<Orders />} />
                    <Route path="/admin/product/add" element={<Addproducts />} />
                    <Route path="/admin/product/edit" element={<EditProduct />} />
                    <Route path="/admin/categories" element={<Categories />} />
                    <Route path="/admin/account" element={<Info />} />
                    <Route path="/admin/account/password" element={<Password />} />
                    <Route path="/admin/specific-setting" element={<SpecificSetting />} />
                    <Route path="/admin/account/manager" element={<Accounts />} />
                    <Route path="/admin/account/add" element={<AddAccounts />} />
                    <Route path="/admin/account/edit" element={<EditAdmin />} />
                </Route>
            </Routes>
        </Router>
    );
}

export default App;
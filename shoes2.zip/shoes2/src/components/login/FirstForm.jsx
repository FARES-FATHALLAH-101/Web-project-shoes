import { TextField } from '@mui/material';
import React from 'react';

const FirstForm = ({ formData, handleChange, handleSubmit }) => {

    return (
        <form className='pt-4' onSubmit={handleSubmit}>
            <div className="row">
                <div className="col">
                    <div className="mb-3">
                        <TextField fullWidth
                            id="fname"
                            name="fname"
                            value={formData.fname}
                            onChange={handleChange}
                            type="text"
                            label="First Name"
                            variant="standard" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <div className="mb-3">
                            <TextField fullWidth
                                id="lname"
                                name="lname"
                                value={formData.lname}
                                onChange={handleChange}
                                type="text"
                                label="Last Name"
                                variant="standard" />
                        </div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col">
                    <div className="mb-3">
                        <TextField
                            fullWidth
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            type="email"
                            label="Email"
                            variant="standard"
                        />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <TextField
                            fullWidth
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            type="password"
                            label="Password"
                            variant="standard"
                        />
                    </div>
                </div>
            </div>
        </form>
    );
};

export default FirstForm;

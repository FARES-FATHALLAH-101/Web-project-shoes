import { TextField } from "@mui/material";
import React from "react";

const SecondForm = ({ formData, handleChange, handleSubmit }) => {
    return (
        <form className='pt-4' onSubmit={handleSubmit}>

            <div className="row">
                <div className="col">
                    <div className="mb-3">
                        <div className="mb-3">
                            <TextField fullWidth
                                id="address"
                                name="address"
                                value={formData.address}
                                onChange={handleChange}
                                type="text"
                                label="Address"
                                variant="standard" />
                        </div>
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <div className="mb-3">
                            <div className="mb-3">
                                <TextField fullWidth
                                    id="city"
                                    name="city"
                                    value={formData.city}
                                    onChange={handleChange}
                                    type="text"
                                    label="City"
                                    variant="standard" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="row">
                <div className="col">
                    <div className="mb-3">
                        <TextField fullWidth
                            id="country"
                            name="country"
                            value={formData.country}
                            onChange={handleChange}
                            type="text"
                            label="Country"
                            variant="standard" />
                    </div>
                </div>
                <div className="col">
                    <div className="mb-3">
                        <TextField fullWidth
                            id="postal_code"
                            name="postal_code"
                            value={formData.postal_code}
                            onChange={handleChange}
                            type="text"
                            label="Postal Code"
                            variant="standard" />
                    </div>
                </div>
            </div>
        </form>
    );
};
export default SecondForm;

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook } from '@fortawesome/free-brands-svg-icons';
import './style.css'
import { faCircleXmark } from '@fortawesome/free-solid-svg-icons';
import icon from './../assets/images/google.png';
import logo from './../assets/images/logo.svg';
import Register from './Register';
import { useState } from 'react';
import { Alert, CircularProgress, IconButton, TextField } from '@mui/material';
import axios from 'axios';
import { useNavigate } from 'react-router';

function Login({ onCloseForm }) {
    const [showRegisterForm, setRegisterForm] = useState(false);
    const [showLoginForm, setShowLoginForm] = useState(false);
    const handleCloseForm = () => {
        onCloseForm();
        document.body.style.overflow = 'auto';
    };
    const handleRegister = () => {
        setShowLoginForm(false)
        setRegisterForm(true);
        document.body.style.overflow = 'hidden';
    }

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const navigate = useNavigate();
    const [isRegistering, setIsRegistering] = useState(false);

    const handelSubmitLogin = async (e) => {
        e.preventDefault();
        setIsRegistering(true)


        try {
            const response = await axios.post('http://127.0.0.1:8000/api/login', {
                email,
                password,
            });

            if (response.status === 200) {
                const { token,fname, role } = response.data;
                localStorage.setItem('auth_token', token);
                localStorage.setItem('auth_name', fname);
                localStorage.setItem('role', role);
                setIsRegistering(false);

                if (role === 'admin') {
                    navigate('/admin');
                    onCloseForm();
                } else if (role === 'user') {
                    navigate('/');
                    onCloseForm();
                }
            } else {
                setIsRegistering(false);
                setError('Invalid credentials');
            }
        } catch (error) {
            setIsRegistering(false);
            setError('An error occurred');
        }
    };
    if (isRegistering) {
        return <CircularProgress />;
    }
    return (

        <div className="container login">
            <div className="row justify-content-center">
                <div className="col-md-8 col-form">
                    <h2 className='text-center title-col-login'>Sign in</h2>
                    {error && <Alert severity="error">Email Or Password Incorrct .</Alert>}
                    <form onSubmit={handelSubmitLogin}>
                        <div className="mb-3">
                            <div className="mb-3">
                                <div className="mb-3">
                                    <TextField fullWidth
                                        id="email"
                                        name="email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        type="email"
                                        label="Email"
                                        required
                                        variant="standard" />
                                </div>
                            </div>
                        </div>
                        <div className="mb-3">
                            <div className="mb-3">
                                <div className="mb-3">
                                    <TextField
                                        fullWidth
                                        required
                                        id="password"
                                        name="password"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        type="password"
                                        label="Password"
                                        variant="standard"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="mb-3 a-col-login text-center">
                            <a href="/">Forgot Your Password?</a>
                        </div>
                        <div className="mb-3 text-center button-col-login">
                            <button className='text-center ' type="submit">Sign in</button>
                        </div>
                        <div>
                            <p className="divider line one-line">Or continue with</p>
                        </div>
                        <div className="d-flex" style={{ justifyContent: 'space-evenly' }}>
                            <div>
                                <FontAwesomeIcon icon={faFacebook} style={{ color: "#005eff", fontSize: '45px' }} />
                            </div>
                            <div>
                                <img width="48" height="48" src={icon} alt="google-logo" />
                            </div>
                        </div>
                    </form>
                </div>
                <div className="col-md-4  col-right">
                    <div style={{ textAlign: 'end' }} >
                        <FontAwesomeIcon icon={faCircleXmark} style={{ color: '#fff', fontSize: '30px', paddingTop: '5px', cursor: 'pointer' }} onClick={handleCloseForm} />
                    </div>
                    <div>
                        <img src={logo} alt="Logo" className="img-fluid mb-4" />
                    </div>
                    <div className="button-col-login p-4 text-center">
                        <button onClick={handleRegister}>Register</button>
                    </div>
                </div>
            </div>
            {showLoginForm && (
                <div className="overlay-form">
                    <Login onCloseForm={handleCloseForm} />
                </div>
            )
            }
            {
                showRegisterForm && (
                    <div className="overlay-form">
                        <Register onCloseForm={handleCloseForm} />
                    </div>
                )
            }
        </div>


    );
}
export default Login;
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './style.css';
import { faFacebook } from '@fortawesome/free-brands-svg-icons';
import { faCircleXmark } from '@fortawesome/free-solid-svg-icons';
import icon from './../assets/images/google.png';
import logo from './../assets/images/logo.svg';
import FirstForm from './FirstForm';
import SecondForm from './SecondForm';
import { Alert, CircularProgress, Step, StepLabel, Stepper } from '@mui/material';
import { Button } from '@mui/material';
import { Navigate, useNavigate } from 'react-router';
import Login from './Login';

function Register({ onCloseForm }) {
    const [showRegisterForm, setRegisterForm] = useState(false);
    const [showLoginForm, setShowLoginForm] = useState(false);
    const handleCloseForm = () => {
        onCloseForm();
        document.body.style.overflow = 'auto';
    };
    const handleLogin = () => {
        setShowLoginForm(true)
        setRegisterForm(false);
        document.body.style.overflow = 'hidden';
    }
    const [isRegistering, setIsRegistering] = useState(false);
    const [isFinished, setIsFinished] = useState(false);
    const navigate = useNavigate();
    const [activeStep, setActiveStep] = useState(0);
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        fname: '',
        lname: '',
        address: '',
        city: '',
        country: '',
        postal_code: '',
    });


    useEffect(() => {
        if (isFinished) {
            navigate('/');
            onCloseForm();
        }
    }, [isFinished, navigate]);

    const handleSubmit = (e) => {
        e.preventDefault();
        setIsRegistering(true);
        axios
            .post('http://127.0.0.1:8000/api/register', formData)
            .then((response) => {
                setFormData({
                    fname: '',
                    lname: '',
                    email: '',
                    password: '',
                    address: '',
                    city: '',
                    country: '',
                    postal_code: '',
                });
                localStorage.setItem('auth_token', response.data.token);
                localStorage.setItem('auth_name', formData.fname);
                localStorage.setItem('auth_user', JSON.stringify(response.data));
                localStorage.setItem('auth_id', formData.id);
                setIsRegistering(false);
                setIsFinished(true);
            })
            .catch((error) => {
                if (error.response && error.response.data && error.response.data.errors) {

                } else {
                    console.error(error);
                }
            });
    };

    const handleNext = () => {
        setActiveStep((prevStep) => prevStep + 1);
    };


    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData((prevData) => ({ ...prevData, [id]: value }));
    };

    const renderFormStep = (step) => {
        switch (step) {
            case 0:
                return <FirstForm formData={formData} handleChange={handleChange} handleNext={handleNext} />;
            case 1:
                return (
                    <SecondForm
                        formData={formData}
                        handleChange={handleChange}
                        handleNext={handleNext}
                    />
                );
            default:
                return null;
        }
    };

    if (isRegistering) {
        return <CircularProgress />;
    }
    return (
        <div className="container register">
            <div className="row justify-content-center">
                <div className="col-md-4  col-right">
                    <div style={{ textAlign: 'start' }} >
                        <FontAwesomeIcon icon={faCircleXmark} style={{ color: '#fff', fontSize: '30px', paddingTop: '5px', cursor: 'pointer' }} onClick={handleCloseForm} />
                    </div>
                    <div>
                        <img src={logo} alt="Logo" className="img-fluid mb-4" />
                    </div>
                    <div className="button-col-login p-4 text-center">
                        <button onClick={handleLogin}>Register</button>
                    </div>
                </div>
                <div className="col-md-8 col-form">
                    <h2 className='text-center title-col-login'>Register</h2>
                    <Stepper activeStep={activeStep}>
                        <Step>
                            <StepLabel>Account</StepLabel>
                        </Step>
                        <Step>
                            <StepLabel>Personal Info</StepLabel>
                        </Step>
                    </Stepper>
                    <div>
                        {renderFormStep(activeStep)}

                        <div className='d-flex justify-content-center'>
                            {activeStep !== 1 ? (
                                <Button type="submit" variant="contained" color="primary" onClick={handleNext}>
                                    Next
                                </Button>
                            ) : (
                                <Button variant="contained" color="primary" onClick={handleSubmit}>
                                    Submit
                                </Button>
                            )}
                        </div>
                        <div>
                            <p className="divider line one-line">Or continue with</p>
                        </div>
                        <div className="d-flex" style={{ justifyContent: 'space-evenly' }}>
                            <div >
                                <FontAwesomeIcon icon={faFacebook} style={{ color: "#005eff", fontSize: '45px' }} />
                            </div>
                            <div>
                                <img width="48" height="48" src={icon} alt="google logo" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {showLoginForm && (
                <div className="overlay-form">
                    <Login onCloseForm={handleCloseForm} />
                </div>
            )
            }
            {
                showRegisterForm && (
                    <div className="overlay-form">
                        <Register onCloseForm={handleCloseForm} />
                    </div>
                )
            }
        </div>

    );
}

export default Register;

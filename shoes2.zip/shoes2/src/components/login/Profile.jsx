import React, { useEffect, useState } from 'react';
import './style.css';
import { Avatar, Button, CircularProgress, TextField, Alert } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import { SettingsApplicationsOutlined } from '@mui/icons-material';
import axios from 'axios';
function Profile() {
    const [activeTab, setActiveTab] = useState('about');
    const [showAlert, setShowAlert] = useState(false)
    const storedUser = JSON.parse(localStorage.getItem('auth_user'));
    const firstCharacter = storedUser.user.fname.charAt(0);
    const userId = storedUser.user.id;
    const handleTabChange = (tab) => {
        setActiveTab(tab);
    };
    const [fname, setFname] = useState(storedUser.user.fname);
    const [lname, setLname] = useState(storedUser.user.lname);
    const [email, setEmail] = useState(storedUser.user.email);
    const [address, setAddress] = useState(storedUser.user.address);
    const [city, setCity] = useState(storedUser.user.city);
    const [country, setCountry] = useState(storedUser.user.country);
    const [postalCode, setPostalCode] = useState(storedUser.user.postal_code);

    // Password
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('')
    const navigate = useNavigate();
    const [errorMessage, setErrorMessage] = useState('');


    const handlSubmit = async (e) => {
        e.preventDefault();
        try {
            const formData = new FormData();
            formData.append('fname', fname);
            formData.append('lname', lname);
            formData.append('email', email);
            formData.append('address', address);
            formData.append('city', city);
            formData.append('country', country);
            formData.append('postal_code', postalCode);

            const response = await axios.post(`http://127.0.0.1:8000/api/update/${userId}`, formData);
            localStorage.setItem('auth_user', JSON.stringify(response.data));
            localStorage.setItem('auth_name', fname);
            navigate('/profile');
            setShowAlert(true)

        } catch (error) {
            console.error(error);
        }
    };
    const handleSubmitPassword = async (e) => {
        e.preventDefault()
        try {
            const response = await axios.post(`http://127.0.0.1:8000/api/change-password/${userId}`, {
                oldPassword,
                newPassword,
            });
            setOldPassword('');
            setNewPassword('');
            setConfirmPassword('');
            setShowAlert(true)
        } catch (error) {
            if (error.response) {
                const errorMessage = error.response.data.message;
                setErrorMessage(errorMessage);
            }
        }

    }
    const handleClose = () => {
        setShowAlert(false);
    };
    return (
        <div className="container">
            <div className="container pt-4">
                <nav aria-label="breadcrumb ">
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><Link to='/'>Home</Link></li>
                        <li className="breadcrumb-item"><Link to='/profile'>Profile</Link></li>
                    </ol>
                </nav>
            </div>
            <div className="row p-5 profile-page">
                <div className="col-md-3">
                    <div className="avatar d-flex justify-content-center">
                        <Avatar sx={{ width: 90, height: 90 }} style={{ fontSize: '45px' }}>{firstCharacter}</Avatar>
                    </div>
                    <ul className="nav flex-column d-flex align-content-center">
                        <li className="nav-item">
                            <a
                                className={`nav-link ${activeTab === 'about' ? 'active' : ''}`}
                                onClick={() => handleTabChange('about')}
                            >
                                Personal Information
                            </a>
                        </li>
                        <li className="nav-item">
                            <a
                                className={`nav-link ${activeTab === 'password' ? 'active' : ''}`}
                                onClick={() => handleTabChange('password')}
                            >
                                Change Password
                            </a>
                        </li>
                        <li className="nav-item">
                            <a
                                className={`nav-link ${activeTab === 'friends' ? 'active' : ''}`}
                                onClick={() => handleTabChange('friends')}
                            >
                                Traking Orders
                            </a>
                        </li>
                    </ul>
                </div>
                <div className="col-md-9">
                    <div className="tab-content">
                        <div
                            id="about"
                            className={`tab-pane fade ${activeTab === 'about' ? 'show active' : ''}`}
                        >
                            {showAlert && <div className='d-flex justify-content-end'>
                                <Alert severity="success" onClose={handleClose}>Changes Saved</Alert>
                            </div>}
                            <h3>Account Settings</h3>
                            <form onSubmit={handlSubmit}>
                                <div className="row">
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="fname"
                                            onChange={e => setFname(e.target.value)}
                                            value={fname}
                                            label="First Name"
                                            variant="standard"
                                        />
                                    </div>
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="lname"
                                            onChange={e => setLname(e.target.value)}
                                            value={lname}
                                            label="Last Name"
                                            variant="standard"
                                        />
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="email"
                                            onChange={e => setEmail(e.target.value)}
                                            value={email}
                                            label="Email"
                                            variant="standard"
                                        />
                                    </div>
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="address"
                                            onChange={e => setAddress(e.target.value)}
                                            value={address}
                                            label="Address"
                                            variant="standard"
                                        />
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="postalcode"
                                            onChange={e => setPostalCode(e.target.value)}
                                            value={postalCode}
                                            label="Postal Code"
                                            variant="standard"
                                        />
                                    </div>
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="city"
                                            onChange={e => setCity(e.target.value)}
                                            value={city}
                                            label="City"
                                            variant="standard"
                                        />
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="country"
                                            onChange={e => setCountry(e.target.value)}
                                            value={country}
                                            label="Country"
                                            variant="standard"
                                        />
                                    </div>
                                </div>
                                <div className='pt-4'>
                                    <Button type="submit" variant="contained">Save</Button>
                                </div>

                            </form>
                        </div>
                        <div
                            id="password"
                            className={`tab-pane fade ${activeTab === 'password' ? 'show active' : ''}`}
                        >
                            {showAlert && (
                                <div className='d-flex justify-content-end'>
                                    <Alert severity="success" onClose={handleClose}>Changes Saved</Alert>
                                </div>
                            )}

                            {errorMessage && (
                                <div className='d-flex justify-content-end'>
                                    <Alert severity="error" onClose={handleClose}>Old Password Incorrect</Alert>
                                </div>
                            )}


                            <h3>Password Settings</h3>
                            <form onSubmit={handleSubmitPassword}>
                                <div className="row">
                                    <div className="col-md-6 pt-3">
                                        <TextField
                                            fullWidth
                                            id="oldPassword"
                                            onChange={(e) => setOldPassword(e.target.value)}
                                            value={oldPassword}
                                            label="Old Password"
                                            variant="standard"
                                            type='password'
                                            required
                                        />
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-6 pt-3">
                                        <TextField fullWidth id="newPassword" type='password' required onChange={e => setNewPassword(e.target.value)} value={newPassword} label="New Password" variant="standard" />
                                    </div>
                                    <div className="col-md-6 pt-3">
                                        <TextField fullWidth id="cPassword" type='password' required onChange={e => setConfirmPassword(e.target.value)} value={confirmPassword} label="Confirm new password" variant="standard" />
                                    </div>
                                </div>
                                <div className='pt-4'>
                                    <Button type="submit" variant="contained">Save</Button>
                                </div>
                            </form>
                        </div>
                        <div
                            id="friends"
                            className={`tab-pane fade ${activeTab === 'friends' ? 'show active' : ''}`}
                        >
                            <h3>Tracking Orders</h3>
                            <p>Soon (:</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Profile;

import { faCartShopping, faEye, faPlus } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import styled from "styled-components";
import './style.css'
import { Link, useParams } from "react-router-dom";
import { data } from "jquery";
import axios from "axios";
import { useEffect, useState } from "react";
import Rating from '@mui/material/Rating';
import { MenuItem, TextField } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { ajouter } from '../store/actions';
export default function Sproduct(props) {
    const dispatch = useDispatch();
    const dataSelector = useSelector((state) => state.panier);

    const Title = styled.h2`
    font-family: Poppins;
    font-style: normal;
    font-weight: 700;
    font-size: 35px;

    @media (max-width: 768px) {
        font-size: 28px;
    }
`;
    const Titl = styled.h2`
        font-family: Poppins;
        font-variant: all-petite-caps;
        border-bottom: 5px solid #292d3245;
        width: fit-content;
        margin: 0 auto;
        padding-bottom: 10px;
        @media (max-width: 768px) {
            font-size: 1.5rem;
            text-align: center;
            border-bottom-width: 15%;
        }
    `;

    const BorderBottom = styled.div`
    border-bottom: 5px solid rgba(41, 45, 50, 0.27);
    width: 25%;

    @media (max-width: 768px) {
        width: 50%;
    }
`;


    const { idPrd } = useParams()
    const prod = props.data.find((elm) => {
        return elm.id === parseInt(idPrd);
    })

    const [dataa, setstate] = useState([])

    const fetch = async () => {
        const res = await axios.get('http://127.0.0.1:8000/api/reviews')
        setstate(res.data.data)
    }

    useEffect(() => {
        fetch();
    }, [])

    const comment = dataa.filter((elm) => {
        return elm.product_id === parseInt(idPrd);
    })

    // pour aficher formulaire
    const [form, setform] = useState(false);
    const setformulaire = () => {
        return setform(true);
    }
    const setformulaireee = () => {
        return setform(false);
    }

    const [Ratingg, setRating] = useState('')
    const [Commentaire, setCommentaire] = useState('')
    const [Product_id, setProduct_id] = useState(parseInt(idPrd))


    const handleSubmit = async (event) => {
        const storedUser = JSON.parse(localStorage.getItem('auth_user'));
        const userId = storedUser.user.id;
        console.log('id: ', userId);
        event.preventDefault();
        try {
            const formData = new FormData();
            formData.append('rating', Ratingg);
            formData.append('comment', Commentaire);
            formData.append('product_id', Product_id);
            formData.append('User_id', userId);


            await axios.post('http://127.0.0.1:8000/api/review', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

        } catch (error) {
            console.error(error);
        }
    };
    const discountedPrice = prod.price - (prod.price * prod.discount / 100);
    const discount = discountedPrice.toFixed(2);
    const images = prod.images.split(',');
    const firstImage = images[0].trim();

    return (
        <div className="container">
            <div className="container pt-4">
                <nav aria-label="breadcrumb ">
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><Link to='/'>Home</Link></li>
                        <li className="breadcrumb-item"><Link to='/products'>Products</Link></li>
                        <li className="breadcrumb-item active" aria-current="page">{prod?.description}</li>
                    </ol>
                </nav>
            </div>
            {prod && (<div className="row d-flex">
                <div className="col-12 col-md-6 pt-5">
                    <div className="title">
                        <Title>{prod.name}</Title>
                        <BorderBottom />
                    </div>
                    <div class="rating position-absolute">
                        <Rating name="rating" size="large" value={4} readOnly />

                    </div>
                    <div className="pt-5">
                        <div className="d-flex align-items-end fw-bold">Old Price : <span className="d-price-old text-danger"> {prod.price} DH</span></div>
                        <div className="d-flex align-items-end fw-bold">New Price : <span className="d-price-new text-primary"> {discount} DH</span></div>
                    </div>
                    <div className="pt-3">
                        <h4>Description</h4>
                        <p className="description-p">
                            {prod.description}
                        </p>
                    </div>
                    <div>
                        <ul className="list-unstyled list-group" style={{
                            paddingLeft: '15px',
                        }}>
                            <li><FontAwesomeIcon icon={faPlus} className="iconPlus" /> Category : {prod.category.name}</li>
                            <li><FontAwesomeIcon icon={faPlus} className="iconPlus" /> Color    :  {prod.colors[0].color}</li>
                            <li><FontAwesomeIcon icon={faPlus} className="iconPlus" /> Stock    :  {prod.quantity}</li>
                            <li><FontAwesomeIcon icon={faPlus} className="iconPlus" /> Size    :  {prod.sizes[0].size}</li>
                            <li><FontAwesomeIcon icon={faPlus} className="iconPlus" /> Shipping : Free</li>
                        </ul>
                    </div>
                    <div class="btn-group pt-4" style={{
                        paddingLeft: '15px',
                    }}>
                        <input class="btn btn-outline-primary" type="number" name="quantity" min="1" max="20" value='20' />

                        <Link to="/panier" class="btn btn-primary" onClick={() => dispatch(ajouter(prod, dataSelector))}>
                            Add To Carte
                        </Link>

                    </div>
                </div>
                <div className="col-12 col-md-6" style={{ position: 'relative', bottom: '4pc' }}>
                    <div className="row">
                        <div className="col">
                            <img src={`http://127.0.0.1:8000/storage/product/image/${firstImage}`}
                                className="img-fluid"
                            />
                        </div>
                    </div>
                </div>
            </div>)}

            <div className="row pt-5 cart-gap">
                <div>
                    <Titl>YOU MAY ALSO LIKE</Titl>
                </div>
                <div className="col-sm-6 col-md-4 col-lg-3">
                    <div className="cart" style={{ width: "18rem" }}>
                        <div className="img-container">
                            <img className="card-img-top" src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/4b01331d-a93f-4c4f-b618-ff21c2877255/court-borough-low-2-se-big-kids-shoes-5n5Wzk.png" alt="Card image cap" />
                            <div className="overlay">
                                <a href="#" className="icon" title="View">
                                    <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                </a>
                                <a href="#" className="icon" title="Add to Cart">
                                    <FontAwesomeIcon icon={faCartShopping} style={{
                                        color: 'white',
                                        paddingLeft: '3px'
                                    }} />
                                </a>
                            </div>
                        </div>
                        <div className="card-body text-center">
                            <div className="d-flex align-items-baseline fixed-height-title">
                                <h5 className="card-title">Nike</h5>
                            </div>
                            <div className="fw-bold pt-4 price">
                                <p className="old-price">1000 DH</p>
                                <p className="new-price">1000 DH</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="col-sm-6 col-md-4 col-lg-3">
                    <div className="cart" style={{ width: "18rem" }}>
                        <div className="img-container">
                            <img className="card-img-top" src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/2016a636-2953-41b4-b496-55263f2b26bc/air-jordan-1-mid-shoes-X5pM09.png" alt="Card image cap" />
                            <div className="overlay">
                                <a href="#" className="icon" title="View">
                                    <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                </a>
                                <a href="#" className="icon" title="Add to Cart">
                                    <FontAwesomeIcon icon={faCartShopping} style={{
                                        color: 'white',
                                        paddingLeft: '3px'
                                    }} />
                                </a>
                            </div>
                        </div>
                        <div className="card-body text-center">
                            <div className="d-flex align-items-baseline fixed-height-title">
                                <h5 className="card-title">Nike</h5>
                            </div>
                            <div className="fw-bold pt-4 price">
                                <p className="old-price">1000 DH</p>
                                <p className="new-price">1000 DH</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="col-sm-6 col-md-4 col-lg-3">
                    <div className="cart" style={{ width: "18rem" }}>
                        <div className="img-container">
                            <img className="card-img-top" src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/3b8a8a4b-7dcb-4495-a3aa-83386f143cc8/air-jordan-1-mid-se-mens-shoes-Zn07hL.png" alt="Card image cap" />
                            <div className="overlay">
                                <a href="#" className="icon" title="View">
                                    <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                </a>
                                <a href="#" className="icon" title="Add to Cart">
                                    <FontAwesomeIcon icon={faCartShopping} style={{
                                        color: 'white',
                                        paddingLeft: '3px'
                                    }} />
                                </a>
                            </div>
                        </div>
                        <div className="card-body text-center">
                            <div className="d-flex align-items-baseline fixed-height-title">
                                <h5 className="card-title">Nike</h5>
                            </div>
                            <div className="fw-bold pt-4 price">
                                <p className="old-price">1000 DH</p>
                                <p className="new-price">1000 DH</p>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="col-sm-6 col-md-4 col-lg-3">
                    <div className="cart" style={{ width: "18rem" }}>
                        <div className="img-container">
                            <img className="card-img-top" src="https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/3b8a8a4b-7dcb-4495-a3aa-83386f143cc8/air-jordan-1-mid-se-mens-shoes-Zn07hL.png" alt="Card image cap" />
                            <div className="overlay">
                                <a href="#" className="icon" title="View">
                                    <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                </a>
                                <a href="#" className="icon" title="Add to Cart">
                                    <FontAwesomeIcon icon={faCartShopping} style={{
                                        color: 'white',
                                        paddingLeft: '3px'
                                    }} />
                                </a>
                            </div>
                        </div>
                        <div className="card-body text-center">
                            <div className="d-flex align-items-baseline fixed-height-title">
                                <h5 className="card-title">Nike</h5>
                            </div>
                            <div className="fw-bold pt-4 price">
                                <p className="old-price">1000 DH</p>
                                <p className="new-price">1000 DH</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <section className="border">
                <div class="row">
                    <div class="col-sm-12">
                        <h3 class="p-3 title-comment-1">CUSTOMER REVIEWS</h3>
                        <button class="p-3 title-comment-2" style={{ border: "none", background: "none" }} onClick={setformulaire}>Write a review</button>
                    </div>
                    {comment.map((i) => {
                        const dateObject = new Date(i.created_at);
                        const options = {
                            weekday: 'short',
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour12: true,
                            hour: 'numeric',
                            minute: 'numeric',
                        };
                        const formattedDate = dateObject.toLocaleString('en-US', options);

                        return (
                            <>
                                <div className="col-sm-12">
                                    <div className="border-bottum"></div>
                                </div>
                                <div className="col-sm-12">
                                    <div className="x p-3">
                                        <Rating name="size-large" defaultValue={i.rating} size="large" />
                                    </div>
                                    <div className="comment">
                                        <h5>{i.user.fname} {i.user.lname} on {formattedDate} </h5>
                                        <p className="fw-bold">{i.comment}</p>
                                    </div>
                                </div>
                            </>
                        );
                    })}
                    {form ?
                        <div class="col-sm-12" style={{ marginLeft: "20px" }}>
                            <div className="border-bottum"></div>
                            <form onSubmit={handleSubmit}>
                                <div className="row">
                                    <div className="col-md-6">

                                        <div className="form-group pt-3">
                                            <Rating name="rating" size="large" onChange={(e) => setRating(e.target.value)} value={Ratingg} required />
                                        </div>
                                        <div className="form-group pt-3">
                                            <TextField fullWidth id="Commentaire" label="Commentaire" onChange={(e) => setCommentaire(e.target.value)} value={Commentaire} variant="standard" name="comment" required />
                                        </div>

                                        <TextField fullWidth id="product_id" variant="standard" name="p" value={idPrd} required type="hidden" />

                                        <div className="text-right mt-3">
                                            <button type="submit" className="btn btn-success">Save</button>&nbsp;
                                            {/* <button type="submit" className="btn btn-primary" onClick={setformulaireee}>back</button>&nbsp; */}
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        : <></>}
                </div>
            </section>
        </div>
    )
}
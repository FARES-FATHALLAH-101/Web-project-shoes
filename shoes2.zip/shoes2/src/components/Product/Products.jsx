import styled from "styled-components";
import axios from "axios";
import { useEffect, useState } from "react";
import { faCartShopping, faEye, faGrip, faGripVertical } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import './style.css'
import { Link } from "react-router-dom";
import img1 from './../assets/images/navbar.png';
import ViewModuleRoundedIcon from '@mui/icons-material/ViewModuleRounded';
import ViewListRoundedIcon from '@mui/icons-material/ViewListRounded';
import { IconButton, Pagination } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { ajouter } from '../store/actions';
function Products() {
    const dispatch = useDispatch();
    const dataSelector = useSelector((state) => state.panier);
    const [isGridView, setIsGridView] = useState(true);
    const toggleGridView = () => {
        setIsGridView(false);
    };
    const toggleGridViewlist = () => {
        setIsGridView(true);
    };
    const Title = styled.h2`
        font-family: Poppins;
        font-variant: all-petite-caps;
        border-bottom: 5px solid #292d3245;
        width: fit-content;
        margin: 0 auto;
        padding-bottom: 10px;
        @media (max-width: 768px) {
            font-size: 1.5rem;
            text-align: center;
            border-bottom-width: 15%;
        }
    `;
    const Select = styled.select`
        border: none;
        outline: none;
        font-family: Poppins;
        width: 45%;
        font-size: 19px;
        color: rgb(96, 96, 96);
        opacity: 0.8;
        text-align: center;
        &:hover {
        background-color: white;
        }
    `;

    const H4 = styled.p`
        color: #606060;
        opacity: 80%;
    `;
    const [categories, setCategories] = useState([]);
    useEffect(() => {
        axios.get('http://127.0.0.1:8000/api/categoryAffichProducts')
            .then(response => {
                setCategories(response.data);
            })
            .catch(error => {
                console.log(error);
            });
    }, []);

    const [products, setProducts] = useState([]);
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [selectedFilter, setSelectedFilter] = useState(null);
    useEffect(() => {
        axios.get('http://127.0.0.1:8000/api/products')
            .then(response => {
                setProducts(response.data);
                setFilteredProducts(response.data);

            })
            .catch(error => {
                console.log(error);
            });
    }, []);

    const [newproducts, setNewProducts] = useState([]);
    const [showNewShoes, setShowNewShoes] = useState(false);

    const fetchNewProducts = () => {
        axios.get('http://127.0.0.1:8000/api/new-products')
            .then(response => {
                setNewProducts(response.data);
                setShowNewShoes(!showNewShoes);
            })
            .catch(error => {
                console.log(error);
            });
    };

    const handleLowPriceFilter = () => {
        const sortedProducts = [...products].sort((a, b) => a.price - b.price);
        setFilteredProducts(sortedProducts);
        setSelectedFilter('lowPrice');
    };

    const handleHighPriceFilter = () => {
        const sortedProducts = [...products].sort((a, b) => b.price - a.price);
        setFilteredProducts(sortedProducts);
        setSelectedFilter('highPrice');
    };

    // Category code
    const [selectedCategory, setSelectedCategory] = useState('');
    const filterProductsByCategory = () => {
        axios.get(`http://127.0.0.1:8000/api/products?categoryName=${selectedCategory}`)
            .then(response => {
                setFilteredProducts(response.data);
            })
            .catch(error => {
                console.log(error);
            });
    };

    console.log(selectedCategory)

    //search code
    const [searchQuery, setSearchQuery] = useState("");

    const handleSearch = () => {
        axios
            .get(`http://127.0.0.1:8000/api/products?productName=${searchQuery}`)
            .then((response) => {
                setFilteredProducts(response.data);
            })
            .catch((error) => {
                console.log(error);
            });
    };



    return (
        <div className="container pt-3">
            <div className="container">
                <nav aria-label="breadcrumb ">
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><Link to='/'>Home</Link></li>
                        <li className="breadcrumb-item active" aria-current="page">Products</li>
                    </ol>
                </nav>
            </div>
            <div className="row">
                <Title>All Products</Title>
            </div>


            <div className="text-center pt-4" style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                <input type="text" placeholder="Search" className="responsive-input" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                <div>
                    <a onClick={handleSearch}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" className="bi filter-icon-search bi-search" viewBox="0 0 16 16">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                        </svg>
                    </a>
                </div>
            </div>
            <div className="pt-3 first-filter">
                <div className='li-category'>
                    <ul className="list-unstyled" style={{ display: "flex" }}>
                        <li><a className="text-decoration-none">All</a></li>
                        <select class="form-select" value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                            {categories.map((category) => {
                                return (<option key={category.id}>{category.name}</option>)
                            })}
                        </select>
                        <button class="btn btn-primary" onClick={filterProductsByCategory}>Filter</button>




                    </ul>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div className="icon-products-view" style={{ marginRight: "10px" }} onClick={toggleGridViewlist}>
                        <IconButton >
                            <ViewModuleRoundedIcon />
                        </IconButton>
                    </div>
                    <div className="icon-products-view" onClick={toggleGridView}>
                        <IconButton >
                            <ViewListRoundedIcon />
                        </IconButton>
                    </div>
                </div>
            </div>
            <div className="first-filter">
                <div>
                    {/* <select className="select-filter">
                        <option value="">Choose a brand</option>
                        <option value="brand1">Red</option>
                        <option value="brand2">black</option>
                    </select> */}
                </div>
                <div className="filter-price">
                    <ul className="list-unstyled" style={{ display: "flex", gap: '20px' }}>
                        <li><a onClick={fetchNewProducts} className="text-decoration-none ">New Shoes</a></li>
                        <li><a onClick={handleLowPriceFilter} className="text-decoration-none ">Low Price</a></li>
                        <li><a onClick={handleHighPriceFilter} className="text-decoration-none ">High Price</a></li>
                    </ul>
                </div>

            </div>

            <div className={`row row-cols-1 row-cols-md-2 row-cols-lg-${isGridView ? '4' : '1'} pt-5 cart-gap`}>
                {showNewShoes ? (
                    newproducts.map((item) => {
                        const discountedPrice = item.price - (item.price * item.discount / 100);
                        const discount = discountedPrice.toFixed(2);
                        const images = item.images.split(',');
                        const firstImage = images[0].trim();

                        return (
                            <div className={`col ${isGridView ? 'mb-4' : 'd-flex justify-content-center'}`} key={item.id}>
                                <div className={`cart h-100 ${isGridView ? 'row' : 'list-view w-75'}`}>
                                    <div className={`img-container ${isGridView ? '' : 'w-50'}`}>
                                        <img
                                            className="img-fluid"
                                            src={firstImage}
                                            alt={item.title}
                                        />
                                        <div className="overlay">
                                            <Link to={`/detail/${item.id}`} className="icon" title="View">
                                                <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                            </Link>
                                            <Link to="/panier" className="icon" title="Add to Cart">
                                                <FontAwesomeIcon
                                                    icon={faCartShopping}
                                                    style={{ color: 'white', paddingLeft: '3px' }}
                                                    onClick={() => dispatch(ajouter(item, dataSelector))}
                                                />
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="card-body">
                                        <div className="d-flex align-items-center">
                                            <h5 className="card-title">{item.name}</h5>
                                        </div>
                                        <div className={`${isGridView ? 'd-none' : ''}`}>
                                            <p className="card-title">{item.description}</p>
                                        </div>
                                        <div className="fw-bold pt-4 price">
                                            <p className="old-price">{item.price} DH</p>
                                            <p className="new-price">{discount} DH</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    })
                ) : (
                    filteredProducts.map((item) => {
                        const discountedPrice = item.price - (item.price * item.discount / 100);
                        const discount = discountedPrice.toFixed(2);
                        const images = item.images.split(',');
                        const firstImage = images[0].trim();

                        return (
                            <div className={`col ${isGridView ? 'mb-4' : 'd-flex justify-content-center'}`} key={item.id}>
                                <div className={`cart h-100 ${isGridView ? 'row' : 'list-view w-75'}`}>
                                    <div className={`img-container ${isGridView ? '' : 'w-50'}`}>
                                        <img
                                            className="img-fluid"
                                            src={`http://127.0.0.1:8000/storage/product/image/${firstImage}`}
                                            alt={item.title}
                                        />
                                        <div className="overlay">
                                            <Link to={`/detail/${item.id}`} className="icon" title="View">
                                                <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                            </Link>
                                            <Link to="/panier" className="icon" title="Add to Cart">
                                                <FontAwesomeIcon
                                                    icon={faCartShopping}
                                                    style={{ color: 'white', paddingLeft: '3px' }}
                                                    onClick={() => dispatch(ajouter(item, dataSelector))}
                                                />
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="card-body">
                                        <div className="d-flex align-items-center">
                                            <h5 className="card-title">{item.name}</h5>
                                        </div>
                                        <div className={`${isGridView ? 'd-none' : ''}`}>
                                            <p className="card-title">{item.description}</p>
                                        </div>
                                        <div className="fw-bold pt-4 price">
                                            <p className="old-price">{item.price} DH</p>
                                            <p className="new-price">{discount} DH</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>


            <div className="d-flex justify-content-end">
                <Pagination count={10} size="large" />
            </div>


        </div >
    )

}

export default Products
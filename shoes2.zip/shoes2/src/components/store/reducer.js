const initialState = {
    panier: []
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD":
            return {
                ...state,
                panier: [...state.panier, action.payload]
            };
        case "DEL":
            return {
                ...state,
                panier: state.panier.filter((item) => item.id !== action.payload)
            };
        case "INCREMENT":
            return {
                ...state,
                panier: state.panier.map((item) =>
                    item.id === action.payload ? { ...item, qte: item.qte + 1 } : item
                )
            };
        case "DECREMENT":
            return {
                ...state,
                panier: state.panier.map((item) =>
                    item.id === action.payload ? { ...item, qte: item.qte - 1 } : item
                )
            };
        default:
            return state;
    }
};

export default reducer;

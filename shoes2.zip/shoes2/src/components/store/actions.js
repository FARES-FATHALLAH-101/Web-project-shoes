export function ajouter(produit, state) {
    if (!state.find((u) => produit.id === u.id)) {
        return {
            type: "ADD",
            payload: { ...produit, qte: 1 },
        };
    } else {
        return {
            type: "INCREMENT",
            payload: produit.id,
        };
    }
}

export function supprimer(id) {
    return {
        type: "DEL",
        payload: id,
    };
}


export function decrement(id) {
    return {
        type: "DECREMENT",
        payload: id,
    };
}

export function increment(id) {
    return {
        type: "INCREMENT",
        payload: id,
    };
}

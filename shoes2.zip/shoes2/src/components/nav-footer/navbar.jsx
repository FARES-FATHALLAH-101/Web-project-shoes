import { faBars, faCartShopping, faUser } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import Login from "../login/Login";
import Register from "../login/Register";
import './navfooter.css';
import imgSrc from './../assets/images/logo.svg';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { Avatar } from "@mui/material";
function Navbar() {
    const [showLoginForm, setShowLoginForm] = useState(false);
    const [showRegisterForm, setRegisterForm] = useState(false);
    const isLoggedIn = !!localStorage.getItem('auth_token');
    const name = localStorage.getItem('auth_name');
    const firstLetter = name ? name.charAt(0) : '';

    const navigate = useNavigate();
    const handleLoginClick = () => {
        setShowLoginForm(true);
        setRegisterForm(false);
        document.body.style.overflow = 'hidden';
    };

    const handleRegisterClick = () => {
        setShowLoginForm(false);
        setRegisterForm(true);
        document.body.style.overflow = 'hidden';
    };

    const handleCloseForm = () => {
        setShowLoginForm(false);
        setRegisterForm(false);
        document.body.style.overflow = 'auto';
    }
    const handleLogout = () => {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('auth_name');
        localStorage.removeItem('auth_id');
        localStorage.removeItem('auth_user');
        navigate('/')
    };


    return (
        <>
            <nav className="navbar navbar-expand-lg navbar-light bg-black">
                <div className="container pe-lg-2 p-0">
                    <Link className="navbar-brand mx-auto" to="/">
                        <img
                            src={imgSrc}
                            height="65"
                        />
                    </Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <FontAwesomeIcon icon={faBars} style={{ color: "#ffffff", }} />
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li className="nav-item ">
                                <Link className="nav-link text-light pe-3 me-4 fw-bold " to="/">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-light pe-3 me-4 fw-bold " to="/products">Products</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-light pe-3 me-4 fw-bold " to="/contact">Contact</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-light pe-3 me-4 fw-bold " to="/about">About</Link>
                            </li>
                        </ul>
                        <ul className="navbar-nav icons d-flex  flex-row align-items-center ms-auto mb-2 mb-lg-0">
                            <li className=" nav-item pe-1">
                                <a className="text-reset me-3" href="#">
                                    <FontAwesomeIcon icon={faCartShopping} style={{ color: "#ffffff", }} />
                                    <span className="badge rounded-pill badge-notification bg-danger">1</span>
                                </a>
                            </li>
                            <li className=" nav-item pe-5">
                                {isLoggedIn ? (
                                    <div>
                                        <div class="dropdown" style={{ position: 'relative', top: '10px' }}>
                                            <button type="button" style={{ border: 'none', background: 'none' }} class="dropdown-toggle" data-bs-toggle="dropdown">
                                                <Avatar >{firstLetter}</Avatar>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li style={{ cursor: 'pointer' }} className="dropdown-item"><Link className="text-decoration-none text-dark" to='/profile'>Profile</Link></li>
                                                <li style={{ cursor: 'pointer' }} className="dropdown-item" onClick={handleLogout}>Logout</li>
                                            </ul>
                                        </div>
                                    </div>

                                ) : (
                                    <div>
                                        <div class="dropdown">
                                            <button type="button" style={{ border: 'none', background: 'none' }} class="dropdown-toggle" data-bs-toggle="dropdown">
                                                <AccountCircleIcon sx={{ color: 'white' }} fontSize="large" />
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li style={{ cursor: 'pointer' }} className="dropdown-item" onClick={handleRegisterClick}>Register</li>
                                                <li style={{ cursor: 'pointer' }} className="dropdown-item" onClick={handleLoginClick}>Login</li>
                                            </ul>
                                        </div>
                                    </div>

                                )}
                            </li>
                        </ul>
                    </div >
                </div >
            </nav >
            {showLoginForm && (
                <div className="overlay-form">
                    <Login onCloseForm={handleCloseForm} />
                </div>
            )
            }
            {
                showRegisterForm && (
                    <div className="overlay-form">
                        <Register onCloseForm={handleCloseForm} />
                    </div>
                )
            }

        </>
    )
}

export default Navbar;
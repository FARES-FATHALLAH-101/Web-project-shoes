import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope } from '@fortawesome/free-regular-svg-icons';
import './navfooter.css';
import { faArrowRight, faPhoneVolume } from '@fortawesome/free-solid-svg-icons';
import { faFacebook, faTwitter, faInstagram } from "@fortawesome/free-brands-svg-icons";
import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import Login from '../login/Login';
import Register from '../login/Register';
import logo from '../assets/images/logo.svg'

function Footer2() {
    const [showLoginForm, setShowLoginForm] = useState(false);
    const [showRegisterForm, setRegisterForm] = useState(false);
    const handleLoginClick = () => {
        setShowLoginForm(true);
        setRegisterForm(false);
        document.body.style.overflow = 'hidden';
    };
    const handleRegisterClick = () => {
        setShowLoginForm(false);
        setRegisterForm(true);
        document.body.style.overflow = 'hidden';
    };
    const handleCloseForm = () => {
        setShowLoginForm(false);
        setRegisterForm(false);
        document.body.style.overflow = 'auto';
    }
    const scrollToTop = (event) => {
        event.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    return (
        <footer className="">

            <div className="row  mb-0 mt-5 mx-4 row-2 justify-content-xl-around justify-content-sm-between">
                <div className="col-xl-3 col-lg-6 col-md-6 col-sm-6 pt-4 ">
                    <img src={logo} alt="" className="img-fluid" />
                    {/* <p className="mt-4">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
                            <a href="" className="mt-4">Know More</a> */}
                </div>
                <div className="col-xl-3 col-lg-4 col-md-4 col-sm-6 pt-4 ">
                    <div className="footer-office">
                        <h3>Office</h3>
                        <p>here are <br /> many variations of passages<br />of Lorem Ipsum<br />available</p>
                        <div>
                            <FontAwesomeIcon icon={faEnvelope} style={{ color: "#ffffff", }} />
                            <a href="#" className='text-decoration-none text-light ml-5' style={{ position: "relative", left: '15px' }}> Eshoes.shop@gmail.com</a>
                        </div>
                        <div>
                            <FontAwesomeIcon icon={faPhoneVolume} style={{ color: "#ffffff", }} />
                            <a href="#" className='text-decoration-none text-light ml-5' style={{ position: "relative", left: '15px' }}> 06 97 68 44 24</a>
                        </div>
                    </div>
                </div>
                <div className="col-xl-auto col-lg-6  col-md-6 pt-4 col-sm-6 my-sm-0">
                    <div className="footer-links">
                        <h3>Links</h3>
                        <div onClick={scrollToTop} className='footer-links'>
                            <Link to='/' >Home</Link>
                            <Link to='/products' >Products</Link>
                            <Link to='/about' >About</Link>
                            <Link to='/contact' >Contact</Link>
                        </div>
                        <Link style={{ cursor: 'pointer' }} onClick={handleLoginClick}>login</Link>
                        <Link style={{ cursor: 'pointer' }} onClick={handleRegisterClick}>Register</Link>
                    </div>
                </div>
                <div className="col-xl-auto text-left col-lg-4 col-md-4 col-sm-6 col-12 pt-4 my-sm-0  my-auto">
                    <div className="footer-social">
                        <h3>Social Media</h3>
                        <form style={{ padding: 'inherit' }} className="subscribe-form">
                            <div className="form-group">
                                <input type="email" className="form-control input-contact" placeholder="Enter your e-mail" required />
                            </div>
                            <button style={{ backgroundColor: "#000000", color: "#ffffff", padding: "10px", borderRadius: "5px", border: "none" }}>
                                <FontAwesomeIcon icon={faArrowRight} style={{ marginLeft: "5px", fontSize: '30px' }} />
                            </button>
                        </form>
                        <ul className="list-unstyled">
                            <li>
                                <p className="mb-0 pb-0 mt-5">FOLLOW THE WEB ON SOCIAL NETWORKS</p>
                            </li>
                            <div className="social-icons mt-3">
                                <a href="#"><FontAwesomeIcon icon={faFacebook} style={{ color: "#ffffff", fontSize: '45px' }} /></a>
                                <a href="#"><FontAwesomeIcon icon={faInstagram} style={{ color: "#ffffff", fontSize: '45px' }} /></a>
                                <a href="#"><FontAwesomeIcon icon={faTwitter} style={{ color: "#ffffff", fontSize: '45px' }} /></a>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>

            <div className="text-center p-4">
                <p>© 2023 E SHOES inc. aLL RIGHTS RESERVED</p>
            </div>
            {showLoginForm && (
                <div className="overlay-form">
                    <Login onCloseForm={handleCloseForm} />
                </div>
            )
            }            {
                showRegisterForm && (
                    <div className="overlay-form">
                        <Register onCloseForm={handleCloseForm} />
                    </div>
                )
            }

        </footer>
    )
}

export default Footer2;
import { Button } from '@mui/material';
import React from 'react';
import { supprimer, decrement, increment } from '../store/actions';
import { useSelector, useDispatch } from 'react-redux';
import DeleteIcon from '@mui/icons-material/Delete';
import DoDisturbOnIcon from '@mui/icons-material/DoDisturbOn';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
export default function Panier() {
    const dispatch = useDispatch();
    const data = useSelector((state) => state.panier);
    const handleDecrement = (productId) => {
        dispatch(decrement(productId));
    };
    const handleSupprimer = (productId) => {
        dispatch(supprimer(productId));
    };
    let totalItems = 0;
    data.forEach((item) => {
        totalItems += item.qte;
    });

    let totalPrice = 0;
    data.forEach((item) => {
        totalPrice += item.price * item.qte;
    });


    return (
        <>
            <section className="bg-light py-5">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-9">
                            <div className="border shadow-0">
                                <div className="m-4">
                                    {data.length === 0 ? (
                                        <h4 className="card-title mb-4">Your shopping cart is empty</h4>
                                    ) : (
                                        <>
                                            <h4 className="card-title mb-4">Your shopping cart</h4>
                                            {data.map((p, i) => (
                                                <div className="col" key={i}>
                                                    <div className="row d-flex align-items-center">
                                                        <div className="col">
                                                            <div className="d-flex">
                                                                <img
                                                                    src="https://bootstrap-ecommerce.com/bootstrap5-ecommerce/images/items/11.webp"
                                                                    className="border rounded me-3"
                                                                    style={{ width: "96px", height: "96px" }}
                                                                    alt="Product"
                                                                />
                                                            </div>
                                                        </div>
                                                        <div className="col-md-5">
                                                            <div className="">
                                                                <h5>{p.name}</h5>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-2">
                                                            <div className="">
                                                                <button
                                                                    style={{ border: "none", background: "none" }}
                                                                    onClick={() => handleDecrement(p.id)}
                                                                >
                                                                    <DoDisturbOnIcon style={{ color: "#1976d2" }} />
                                                                </button>
                                                                &nbsp;&nbsp;&nbsp;
                                                                {p.qte}
                                                                &nbsp;&nbsp;&nbsp;
                                                                <button
                                                                    style={{ border: "none", background: "none" }}
                                                                    onClick={() => dispatch(increment(p.id))}
                                                                >
                                                                    <AddCircleIcon style={{ color: "#1976d2" }} />
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div className="col">
                                                            <div className="">
                                                                <h5 className="h6">{p.price}</h5>
                                                            </div>
                                                        </div>
                                                        <div className="col-lg col-sm-6 d-flex justify-content-sm-center justify-content-md-start justify-content-lg-center justify-content-xl-end mb-2">
                                                            <div className="float-md-end">
                                                                <button
                                                                    className="btn btn-danger"
                                                                    onClick={() => handleSupprimer(p.id)}
                                                                >
                                                                    <DeleteIcon />
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </>
                                    )}
                                </div>
                            </div>

                        </div>
                        <div className="col-lg-3">
                            <div className=" shadow-0 border p-4">
                                <h5 className="summary-title">Cart Summary:</h5>
                                <div className="card-body">
                                    <div className="d-flex justify-content-between">
                                        <p className="mb-2">Total Items:</p>
                                        <p className="mb-2">{totalItems}</p>
                                    </div>
                                    <hr />
                                    <div className="d-flex justify-content-between">
                                        <p className="mb-2">Total Price:</p>
                                        <p className="mb-2 fw-bold">{totalPrice.toFixed(2)}</p>
                                    </div>
                                    <div className="mt-3">
                                        <PayPalScriptProvider options={{ "clientId": "AVmlv0D3UeBN8NGpPsjHVHJ4n4IMR4f84hHHWs7he_cwRP3a3q_0JcQ8nqs64_9JEvCyKDtP3aC1deIR" }}>
                                            <PayPalButtons style={{ layout: "horizontal" }} createOrder={(data, actions) => {
                                                return actions.order
                                                    .create({
                                                        purchase_units: [
                                                            {
                                                                amount: {
                                                                    value: totalPrice,

                                                                },

                                                            },
                                                        ],
                                                    })

                                            }}

                                            />
                                        </PayPalScriptProvider>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}
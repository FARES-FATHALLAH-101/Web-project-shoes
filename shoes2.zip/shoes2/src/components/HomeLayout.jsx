
import { Outlet } from 'react-router-dom';
import Navbar from './nav-footer/navbar';
import Footer2 from './nav-footer/footer';


const HomeLayout = () => {
    return (
        <>
            <Navbar />
            <div>
                <Outlet />
            </div>
            <Footer2 />

        </>
    );
};

export default HomeLayout;

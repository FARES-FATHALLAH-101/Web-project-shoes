import './Style.css'
import about from './../assets/images/2.jpg';
import img4 from './../assets/images/4.jpg';
import img5 from './../assets/images/5.png';
import img15 from './../assets/images/img15.jpg';
import img16 from './../assets/images/img16.jpeg';
import img14 from './../assets/images/img14.jpg';
import img6 from './../assets/images/6.jpg';
import img7 from './../assets/images/7.jpg';
import img8 from './../assets/images/8.jpg';
import img9 from './../assets/images/9.jpg';
import map from './../assets/images/map.png';
export default function About() {
    return (
        <div>
            {/* <div className="container">
                <nav aria-label="breadcrumb " style={{ paddingTop: '30px' }}>
                    <ol className="breadcrumb">
                        <li className="breadcrumb-item"><a href="#">Home</a></li>
                        <li className="breadcrumb-item active" aria-current="page">About</li>
                    </ol>
                </nav>
            </div> */}
            <div style={{ position: "relative" }}>
                <img src={about} className="legrun" alt="" />
                <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", textAlign: "center" }}>
                    <h1 style={{ fontSize: "5rem", color: "black" }}>ABOUT US</h1>
                    {/* <div>
                        <a href="/back-about" style={{ color: "white", border: "none", borderRadius: "3px", padding: "0.80rem 2rem", textDecoration: "none" }} className="li">-Back/Contact-</a>
                    </div> */}
                </div>
            </div>

            <section className="bg-primary p-5">
                <div className="container">
                    <div className="title-about">
                        <h4>Category We Are targrting.</h4>
                    </div>
                    <div className="row category-about">
                        <div className="col-md-4 pt-3">
                            <div className="outer-border">
                                <div className="middle-border">
                                    <div className="inner-border">
                                        <img src="https://i.ibb.co/yYjvxVM/Julia-Hofer-Wallpapers-Insta-Fit-Bio-4.jpg" alt="Your Image" />
                                        <div className="text-overlay-about">
                                            <h3>Woman</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4 pt-3">
                            <div className="outer-border">
                                <div className="middle-border">
                                    <div className="inner-border">
                                        <img src="https://contracoutura.pt/wp-content/uploads/2021/03/kidsuper-puma-second-collection-colm-dillane-football-palmeiras-04.jpg" alt="Your Image" />
                                        <div className="text-overlay-about">
                                            <h3>Man</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4 pt-3">
                            <div className="outer-border">
                                <div className="middle-border">
                                    <div className="inner-border">
                                        <img src="https://us.sportsdirect.com/images/marketing/28174_art_adidas_SDi_July_App_F_450x450px4.jpg" alt="Your Image" />
                                        <div className="text-overlay-about">
                                            <h3>kids</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="container">
                <div>
                    <h5 className='text-center pt-4 pb-4'>
                        E Shoes Never Goes Out of Fashion
                    </h5>
                    <div className="row d-flex align-items-center">
                        <div className="col-md-6">
                            <img src={img4}alt="Shoes" width={"100%"} />
                        </div>
                        <div className="col-md-6 ">
                            <p className='title2-about'>
                                Elevate Your Footwear Experience with E Shoes - They Stay Comfortable with You All Day Long!
                            </p>
                            <p className='contant2-about'>
                                Are you someone who loves sports or just wants to find shoes that offer unbeatable comfort throughout the day?
                                Look no further because E Shoes is here to transform your footwear experience. We recognize the significance of
                                wearing shoes that feel well-worn and prepared for action as soon as you slip them on.<br />
                            </p>
                            <p className='title3-about'>Take your footwear game to new heights with E Shoes and relish in the pleasure of each and every step you take!</p>
                        </div>
                    </div>

                </div>
            </div>

            <div className="container">
                <div>
                    <h5 className='pt-4 pb-2'>Discover Our Teams's Story</h5>
                </div>
                <div style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: "justify"
                }}>
                    <div style={{ width: '60%' }}>
                        During the Renaissance, the evolution of shoe fashions from vertical lines preferred by Gothic styles to a more horizontal style was evident. The toe shape, in particular, became increasingly extreme and broad in square form, especially among the wealthier and more influential individuals.

                        Part of the credit for Nike's success can be attributed to the endorsements of renowned athletes like Michael Jordan, Mia Hamm, Roger Federer, and Tiger Woods. NikeTown, a chain of stores that debuted in 1990, not only showcases a wide range of Nike products but also pays homage to these athletes and other spokespersons associated with the company. However, during the 1990s, Nike faced a temporary decline in its public image due to revelations about the unfavorable working conditions in its overseas factories.
                    </div>
                </div>
                <div style={{ width: 'max-content', margin: '0 auto' }}>
                    <div className="outer-border">
                        <div className="middle-border-2">
                            <div className="inner-border-2">
                                <img src={img5} alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container">
                <div className='titre1'>
                    <h5 className='text-center pt-4 pb-4'>
                        The Power of E Shoes
                    </h5>
                    <h5>To Which Place can you reach whit our shoes?</h5>
                    <div style={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        flexDirection: 'column',
                        gap: "10px"
                    }}>

                        <div className="card pt-3" >
                            <div className="circle">
                                <div className="imgBox">
                                    <img src={img15} alt="./img/img15.jpg" className="" />
                                </div>
                            </div>
                            <div className="content">
                                <h3>TO GYM</h3>
                                <div className="textIcon">
                                    <p>
                                        Choosing suitable shoes safeguards against workout-related injuries, promoting safety and protection.
                                    </p>
                                </div>

                            </div>
                        </div>

                        <div className="card pt-3" >
                            <div className="circle">
                                <div className="imgBox">
                                    <img src={img16} alt="./img/img16.jpeg" className="" />
                                </div>
                            </div>
                            <div className="content">
                                <h3>TO RUGGED MOUNTAINS</h3>
                                <div className="textIcon">
                                    <p>
                                        Trail running shoes offer increased traction for stability on rough trails.
                                    </p>
                                </div>


                            </div>
                        </div>

                        <div className="card pt-3" >
                            <div className="circle">
                                <div className="imgBox">
                                    <img src={img14} alt="./img14" className="" />
                                </div>
                            </div>
                            <div className="content">
                                <h3>IN CASE OF BAD WEATHER</h3>
                                <div className="textIcon">
                                    <p>
                                        Trail running shoes provide little protection against wet conditions, including rivers.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
            <div className="container pb-5">
                <h5 className='text-center pt-4 pb-4'>
                    Popular style
                </h5>
                <h5 className='pb-3'>E shoes give you the opportunity to run, for better health.</h5>
                <div className="popular-style-about">
                    <div className="row p-5 d-flex align-items-center">
                        <div className="col-md-6">
                            <h3><span style={{ color: 'gray' }}>Gray.Look, </span>Black.shoes</h3>
                            <p style={{ textAlign: 'justify' }}>
                                These shoes extend up to the ankles. A slip-on ankle boo shoes with an elastic side panel is called a Chelsea shoes, and an ankle boot made of suede or leather with laces is known as a Chukka boot or desert shoes
                                These, thick upper material, and extend up to the ankle. These shoes are used for hiking and walking in different weather conditions. Some hiking boots are insulated for warmth or are waterproof.
                            </p>
                        </div>
                        <div className="col-md-6 pt-4">
                            <div className="row border-popular-style-img ">
                                <div className="col popular-style-img">
                                    <img src={img6} alt="" className='img-fluid' />
                                </div>
                                <div className="col popular-style-img" id='popular-style-img-2'>
                                    <img src={img7} alt="" className='img-fluid' />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row p-5 d-flex align-items-center">
                        <div className="col-md-6 pt-4">
                            <div className="row border-popular-style-img ">
                                <div className="col popular-style-img" id='popular-style-img-2'>
                                    <img src='https://th.bing.com/th/id/OIP.plWVE59nUEVeG4hCcZ9PYQHaHa?pid=ImgDet&rs=1' alt="" className='img-fluid' />
                                </div>
                                <div className="col popular-style-img">
                                    <img src={img9} alt="" className='img-fluid' />
                                </div>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <h3><span style={{ color: 'blue' }}>Blue</span>.shoes</h3>
                            <p style={{ textAlign: 'justify' }}>
                                These shoes extend up to the ankles. A slip-on ankle boot with an elastic side panel is called a Chelsea boot, and an ankle boot made of suede or leather with laces is known as a Chukka boot or desert boot.
                                These boots have a thick upper material and extend up to the ankle. They are commonly used for hiking and walking in various weather conditions. Some hiking boots are insulated for warmth or waterproof.
                            </p>
                        </div>
                    </div>

                </div>
            </div>
            <div className=''>
                <h5 className='text-center pt-4 pb-4'>
                    Our Targets.
                </h5>
                <div className='world-map'>
                    <img src={map} alt="map" className="img" />
                    <div className="custom-tooltip usa">
                        <span className='tooltip-text'>United states</span>
                    </div>
                    <div className="custom-tooltip morocco">
                        <span className='tooltip-text'>Morocco</span>
                    </div>
                    <div className="custom-tooltip saudi-Arabia" >
                        <span className='tooltip-text'>Saudi Arabia</span>
                    </div>

                    <div className="custom-tooltip italy">
                        <span className='tooltip-text'> Italy</span>
                    </div>
                    <div className="custom-tooltip uae">
                        <span className='tooltip-text'>UAE</span>
                    </div>
                    <div className="custom-tooltip algeria">
                        <span className='tooltip-text'>Algeria</span>
                    </div>
                    <div className="custom-tooltip spain">
                        <span className='tooltip-text'>Spain</span>
                    </div>
                </div>
            </div>


        </div>

    )
}
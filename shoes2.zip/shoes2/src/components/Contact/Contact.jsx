import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMapLocationDot, faPhoneVolume } from '@fortawesome/free-solid-svg-icons';
import { faEnvelope } from '@fortawesome/free-regular-svg-icons';
import './Style.css'
import { useRef, useState } from "react";
import emailjs from '@emailjs/browser'
import img from '../assets/images/1.jpg'
import { Alert } from '@mui/material';
const Contact = () => {
    const [sendMail, setSendmail] = useState(false)
    const form = useRef()

    const sendEmail = (e) => {
        e.preventDefault();
        emailjs.sendForm('service_33w6g6u', 'template_jlasrli', form.current, 'BJy2xB_6FjkxS27IR')
            .then((result) => {
                console.log(result.text);
                setSendmail(true)

            }, (error) => {
                console.log(error.text);
            });
        e.target.reset()
    }
    const handleClose = () => {
        setSendmail(false);
      };

    return (
        <div className="">
            {/* <nav aria-label="breadcrumb " style={{ paddingTop: '30px' }}>
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><a href="#">Home</a></li>
                    <li className="breadcrumb-item active" aria-current="page">Contact</li>
                </ol>
            </nav> */}
            <div style={{ position: "relative" }}>
                <img src={img} className="legrun" alt="" />
                <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", textAlign: "center" }}>
                    <h1 style={{ fontSize: "5rem", color: "white" }}>CONTACT</h1>
                    {/* <div>
                        <a href="/back-about" style={{ color: "white", border: "none", borderRadius: "3px", padding: "0.80rem 2rem", textDecoration: "none" }} className="li">-Back/Contact-</a>
                    </div> */}
                </div>
            </div>

            <div className=" container pt-5 containerx">
                <img src="img/shape.png" className="square" alt="" />
                <div className="form">
                    <div className="contact-info">
                        <h3 className="title"> Get in touch</h3>
                        <p className="text">
                        </p>
                        We'love to hear from you.Our friendly teams
                        is always here to chat
                        <div className="info">
                            <div className="information">

                                <FontAwesomeIcon icon={faMapLocationDot} style={{ color: "#ffffff", fontSize: '30px' }} />
                                <p style={{ position: 'relative', top: '10px', left: '10px', }}>Rabat ....</p>

                            </div>

                            <div className="information">
                                <FontAwesomeIcon icon={faEnvelope} style={{ color: "#ffffff", fontSize: '30px' }} />
                                <p style={{ position: 'relative', top: '10px', left: '10px', }}>E shoes@teams.com</p>
                            </div>
                            <div className="information">
                                <FontAwesomeIcon icon={faPhoneVolume} style={{ color: "#ffffff", fontSize: '30px' }} />
                                <p style={{ position: 'relative', top: '10px', left: '10px', }}>06 66 66 66 66</p>
                            </div>
                        </div>
                        <div className="social-media">
                            <p> Stay Connect with us : E shoes</p>

                        </div>
                    </div>
                    <div className="contact-form">
                        <span className="circle one"></span>
                        <span className="circle two"></span>
                        {sendMail ? <Alert onClose={handleClose} severity="success">Email Sent</Alert> : null}
                        <form className='form-contact' ref={form} onSubmit={sendEmail} autoComplete="off">
                            <h3 className="title">Contact us</h3>
                            <div className="input-container">
                                <input type="text" name="name" className="input" />
                                <label htmlFor="">Username:</label>
                                <span>Username</span>
                            </div>
                            <div className="input-container">
                                <input type="email" name="email" className="input" />
                                <label htmlFor="">Email:</label>
                                <span>Email</span>
                            </div>
                            <div className="input-container">
                                <input type="tel" name="phone" className="input" />
                                <label htmlFor="">Phone:</label>
                                <span>Phone</span>
                            </div>
                            <div className="input-container textarea">
                                <textarea name="message" className="input"></textarea>
                                <label for="">Message:</label>
                                <span>Message</span>
                            </div>
                            <input type="submit" value="Send Message" className="btn" />
                        </form>
                    </div>
                </div>
            </div>



        </div>

    );
};
export default Contact;
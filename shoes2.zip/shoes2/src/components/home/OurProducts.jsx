import axios from "axios";
import { useEffect, useState } from "react";
import { faCartShopping, faEye } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";
import img from '../assets/images/14.png'
import { ajouter } from "../store/actions";
import { useDispatch, useSelector } from "react-redux";

export function OurProducts() {
    const [data, setstate] = useState([])

    const fetch = async () => {
        const res = await axios.get('http://127.0.0.1:8000/api/products')
        setstate(res.data)
    }

    useEffect(() => {
        fetch();
    }, [])
    const dispatch = useDispatch();
    const dataSelector = useSelector((state) => state.panier);

    return (
        <div className="container">
            <div className="row pt-5 cart-gap">
                {data.map((item) => {
                    const discountedPrice = item.price - (item.price * item.discount / 100);
                    const discount = discountedPrice.toFixed(2);
                    const images = item.images.split(',');
                    const firstImage = images[0].trim();
                    return (
                        <div className="col-sm-6 col-md-4 col-lg-3 d-flex justify-content-center align-items-center">
                            <div className="cart" style={{ width: "18rem" }}>
                                <div className="img-container">
                                    <img className="card-img-top" src={`http://127.0.0.1:8000/storage/product/image/${firstImage}`}  />
                                    <div className="overlay">
                                        <Link to={`/detail/${item.id}`} className="icon" title="View">
                                            <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                                        </Link>
                                        <Link to="/panier" className="icon" title="Add to Cart">
                                            <FontAwesomeIcon
                                                icon={faCartShopping}
                                                style={{ color: 'white', paddingLeft: '3px' }}
                                                onClick={() => dispatch(ajouter(item, dataSelector))}
                                            />
                                        </Link>
                                    </div>
                                </div>
                                <div className="card-body">
                                    <div className="d-flex align-items-center">
                                        <h5 className="card-title">{item.name}</h5>
                                    </div>
                                    <div className="fw-bold pt-4 price">
                                        <p className="old-price">{item.price} DH</p>
                                        <p className="new-price">{discount} DH</p>
                                    </div>
                                </div>

                            </div>
                        </div>

                    )
                })}
            </div>

        </div>
    )
}

export default OurProducts;
import axios from "axios";
import { useEffect, useState } from "react";
import { faCartShopping, faEye } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export const CartItem = ({ cart }) => {
    const imageName = cart.images ? cart.images.trim() : '';

    return (
        <div className="cart" style={{ width: "18rem" }}>
            <div className="img-container">
                <img className="card-img-top" src={`http://127.0.0.1:8000/storage/product/image/${imageName}`} alt="Card image cap" />
                <div className="overlay">
                    <a href="#" className="icon" title="View">
                        <FontAwesomeIcon icon={faEye} size="xl" style={{ color: 'blue' }} />
                    </a>
                    <a href="#" className="icon" title="Add to Cart">
                        <FontAwesomeIcon icon={faCartShopping} style={{
                            color: 'white',
                            paddingLeft: '3px'
                        }} />
                    </a>
                </div>
            </div>
            <div className="card-body text-center">
                <div className="d-flex align-items-baseline fixed-height-title">
                    <h5 className="card-title">{cart.title}</h5>
                </div>
                <div className="fw-bold pt-4 price">
                    <p className="old-price">{cart.price} DH</p>
                    <p className="new-price">{cart.price} DH</p>
                </div>
            </div>
        </div>
    );
};



export function SpecailNike() {
    const [data, setstate] = useState([]);
    const items = [];

    const fetch = async () => {
        const res = await axios.get('https://api.storerestapi.com/products?limit=7')
        setstate(res.data.data)
    }

    useEffect(() => {
        fetch();
    }, [])


    for (let i = 0; i < data.length; i += 2) {
        items.push(
            <div key={i} className={`carousel-item ${i === 0 ? 'active' : ''}`}>
                <div className="row">
                    <div className="col-sm-12 col-md-6 mb-3 d-flex justify-content-center align-items-center">
                        <CartItem cart={data[i]} />
                    </div>
                    {data[i + 1] && (
                        <div className="col-sm-12 col-md-6 mb-3 d-flex justify-content-center align-items-center">
                            <CartItem cart={data[i + 1]} />
                        </div>
                    )}
                </div>
            </div>
        );
    }

    return (
        <>{items}</>
    );
}

export default SpecailNike;
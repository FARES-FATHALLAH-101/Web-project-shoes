import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronLeft, faChevronRight, faMoneyBillTransfer, faTruckFast } from '@fortawesome/free-solid-svg-icons'
import { faCreditCard } from "@fortawesome/free-regular-svg-icons";
import OurProducts from "./OurProducts";
import SpecailNike from "./SpecailNike";
import img1 from './../assets/images/navbar.png';
import img2 from './../assets/images/12.png';
import img3 from './../assets/images/13.png';
import img4 from './../assets/images/14.png';
import img6 from './../assets/images/home.png';
import img5 from './../assets/images/s.png';
import img7 from './../assets/images/special_baner.png';
import vans from './../assets/images/vans.png';
import nike from './../assets/images/Nike.png';
import adidas from './../assets/images/adidas.png';
import './style.css'
import { Link } from "react-router-dom";

export function Home() {


    return (
        <div>
            <div className='x-home'>
                <div className="container">
                    <div className="row section-home align-items-center">
                        <div className="col-sm-12 col-md-6 landing">
                            <h1>built for flight</h1>
                            <p>This special edition takes it a step further by adding golden accents on the forefoot Swoosh and the home plate hangtag, while strikes of red are seen throughout the straps, heel-tabs, and other minutia.</p>
                            <button className="btn btn-primary">Buy Now</button>
                        </div>
                        <div className="col-sm-12 col-md-6 photo">
                            <img src={img1} alt="Product Photo" />
                        </div>
                    </div>
                </div>
            </div>
            <div className="container categories pt-5">
                <div className="row categorie d-flex align-items-center justify-content-center">
                    <div className="col-md-4 col-sm-6 nike">
                        <div className="row d-flex align-items-center">
                            <div className="col">
                                <div className="img-categorie">
                                    <img src={img2} className="img-fluid" alt="categorie" />
                                </div>
                            </div>
                            <div className="col">
                                <div className="info-categorie">
                                    <a href="#" className="text-decoration-none">
                                        <h1>Nike</h1>
                                    </a>
                                    <p>Nike is one of the most famous sneakers providing companies.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-sm-6 adidas">
                        <div className="row d-flex align-items-center">
                            <div className="col">
                                <div className="img-categorie">
                                    <img src={img3} className="img-fluid" alt="categorie" />
                                </div>
                            </div>
                            <div className="col">
                                <div className="info-categorie">
                                    <a href="#" className="text-decoration-none">
                                        <h1>Adidas</h1>
                                    </a>
                                    <p>German manufacturer of athletic shoes and apparel and sporting goods.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-sm-6 vans">
                        <div className="row d-flex align-items-center">
                            <div className="col">
                                <div className="img-categorie">
                                    <img src={img4} className="img-fluid" alt="categorie" />
                                </div>
                            </div>
                            <div className="col">
                                <div className="info-categorie">
                                    <a href="#" className="text-decoration-none">
                                        <h1>Vans</h1>
                                    </a>
                                    <p>Vans is a well-known American shoe manufacturer with a global presence.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div className="product_lists">
                <div className="title-home text-center">
                    <h1>Our Latest Products</h1>
                </div>
                <OurProducts />
                <div className='text-center our-products-a pt-5 pb-5'>
                    <Link to="/products" className='text-decoration-none'>
                        View More
                    </Link>
                </div>
            </div>
            <div className="container pb-5">
                <div className="row shop_now d-flex justify-content-center">
                    <div className="col-sm-12 col-md-5  shop_Nike">
                        <div className="image-container">
                            <img src={img6} width='170px' />
                            <div className="text-overlay">
                                <h1>Nike Shoes</h1>
                                <p>Makes Yourself Keep Sporty</p>
                                <button>Shop Now</button>
                            </div>
                        </div>
                    </div>
                    <div className="col-sm-12 col-md-5 shop_Vans">
                        <div className="image-container">
                            <img src={img5} width='170px' />
                            <div className="text-overlay">
                                <h1>Vans Shoes</h1>
                                <p>The Summer Sale Off 50%</p>
                                <button>Shop Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container pb-5">
                <div className="row d-flex justify-content-center">
                    <div className="col-sm-12 col-md-6 specail-product">
                        <h1>The Best Collections </h1>
                        <p>50% Off Sale </p>
                        <div className="d-flex flex-column justify-content-center align-items-center">
                            <div className="img_special">
                                <img src={img7} alt="img_banner" width="100%" />
                            </div>
                            <div className='text-center pb-4'>
                                <button>Explore All</button>
                            </div>
                        </div>
                    </div>

                    <div className="col-sm-12 col-md-6">
                        <section oncontextmenu='return false' className='snippet-body pt-5'>
                            <div className="container">
                                <div className="row">
                                    <div className="col-9">
                                        <h3 className="mb-3 title-specail-nike">Nike Special</h3>
                                        <hr />
                                    </div>
                                    <div className="col-3 text-end">
                                        <a className="" data-bs-target="#carouselExampleIndicators2" role="button"
                                            data-bs-slide="prev">
                                            <FontAwesomeIcon icon={faChevronLeft} style={{ color: "#000000", fontSize: '30px' }} />
                                        </a>
                                        <a className="" data-bs-target="#carouselExampleIndicators2" role="button"
                                            data-bs-slide="next">
                                            <FontAwesomeIcon icon={faChevronRight} style={{ color: "#0a0a0a", fontSize: '30px' }} />
                                        </a>
                                    </div>


                                    <div className="col-12">
                                        <div id="carouselExampleIndicators2" className="carousel slide" data-bs-ride="carousel">

                                            <div className="carousel-inner">
                                                <SpecailNike />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>

            <div className="container service_eshoess">
                <div className="row d-flex justify-content-center align-items-center">
                    <div className="col-12 col-lg-4 pt-4">
                        <div className="row">
                            <div className="col-3">
                                <FontAwesomeIcon icon={faTruckFast} style={{ color: "#000000", fontSize: '90px' }} />
                            </div>
                            <div className="col">
                                <h1>FREE SHIPING</h1>
                                <p>All orders over</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-12 col-lg-4 pt-4">
                        <div className="row">
                            <div className="col-3">
                                <FontAwesomeIcon icon={faMoneyBillTransfer} style={{ color: "#000000", fontSize: '90px' }} />
                            </div>
                            <div className="col">
                                <h1>FREE RETURNS</h1>
                                <p>Money back in 15 days</p>
                            </div>
                        </div>
                    </div>
                    <div className="col-12 col-lg-4 pt-4">
                        <div className="row">
                            <div className="col-3">
                                <FontAwesomeIcon icon={faCreditCard} style={{ color: "#000000", fontSize: '90px' }} />
                            </div>
                            <div className="col">
                                <h1>QUICK PAYMENT</h1>
                                <p>100% secure payment</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container text-center">
                <div className="title-partners pt-5">
                    <h1>OUR PARTNERS</h1>
                </div>
                <div className="row d-flex align-items-center">
                    <div className="col-12 col-lg-4 pt-4">
                        <img src={vans} alt="" className="vans-partners" width='80%' />
                    </div>
                    <div className="col-12 col-lg-4 pt-4">
                        <img src={nike} alt="" className="nike-partners" width='80%' />
                    </div>
                    <div className="col-12 col-lg-4 pt-4">
                        <img src={adidas} alt="" className="adidas-partners" width='80%' />
                    </div>
                </div>
            </div>

        </div>



    )
}

export default Home;
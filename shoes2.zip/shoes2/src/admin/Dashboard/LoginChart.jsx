import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const LoginChart = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');

    const chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['2023-06-01', '2023-06-02', '2023-06-03'], // Static array of dates
        datasets: [
          {
            label: 'Number of Users Logged In',
            data: [100, 150, 200], // Static array of user counts
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      // Cleanup the chart instance on component unmount
      chart.destroy();
    };
  }, []);

  return <canvas ref={chartRef} />;
};

export default LoginChart;

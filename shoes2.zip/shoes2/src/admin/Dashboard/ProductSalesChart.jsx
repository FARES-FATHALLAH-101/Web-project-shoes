import React from 'react';
import Chart from 'chart.js/auto';

const ProductSalesChart = () => {
  const chartRef = React.useRef(null);

  React.useEffect(() => {
    let chartInstance = null;
    const ctx = document.getElementById('productSalesChart');

    if (chartRef.current) {
      // Destroy previous chart instance if it exists
      chartRef.current.destroy();
    }

    chartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Product A', 'Product B', 'Product C', 'Product D', 'Product E'],
        datasets: [
          {
            label: 'Product Sales',
            data: [100, 200, 150, 300, 250],
            backgroundColor: 'rgba(75, 192, 192, 0.8)',
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    // Store the chart instance in the ref for future reference
    chartRef.current = chartInstance;
  }, []);

  return <canvas id="productSalesChart" />;
};

export default ProductSalesChart;

import './style.css'
import LoginChart from './LoginChart';
import ProductSalesChart from './ProductSalesChart';
export default function Dashboard() {
    return (
        <div className="dashboard">
            <div className='row g-3 my-2'>
                <div className='col-md-3 col-sm-6 p-2 '>
                    <div className='p-3 bg-primary shadow-sm d-flex justify-content-around align-items-center rounded'>
                        <div>
                            <h3 className='fs-2 text-white'>230</h3>
                            <p className='fs-5 text-white'>Users</p>
                        </div>
                        <i className='bi bi-people-fill p-3 fs-1 text-white'></i>
                    </div>
                </div>
                <div className='col-md-3 col-sm-6 p-2 '>
                    <div className='p-3 bg-primary-subtle shadow-sm d-flex justify-content-around align-items-center rounded'>
                        <div>
                            <h3 className='fs-2 text-white'>2450</h3>
                            <p className='fs-5 text-white'>Sales</p>
                        </div>
                        <i className='bi bi-currency-dollar text-white p-3 fs-1'></i>
                    </div>
                </div>
                <div className='col-md-3 col-sm-6 p-2 '>
                    <div className='p-3 bg-info shadow-sm d-flex justify-content-around align-items-center rounded'>
                        <div>
                            <h3 className='fs-2 text-white'>2250</h3>
                            <p className='fs-5 text-white'>Delivery</p>
                        </div>
                        <i className='bi bi-truck p-3 text-white fs-1'></i>
                    </div>
                </div>
                <div className='col-md-3 col-sm-6 p-2 '>
                    <div className='p-3 bg-info-subtle shadow-sm d-flex justify-content-around align-items-center rounded'>
                        <div>
                            <h3 className='fs-2 text-white'>20</h3>
                            <p className='fs-5 text-white'>Unique visits</p>
                        </div>
                        <i className='bi bi-pin-angle-fill text-white  p-3 fs-1'></i>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col">
                    <LoginChart />
                </div>
                <div className="col">
                    <ProductSalesChart />
                </div>
            </div>
        </div>
    )
}
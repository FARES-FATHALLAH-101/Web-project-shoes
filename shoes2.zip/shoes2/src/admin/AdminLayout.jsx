import React from 'react';
import Navbar from './Navbar/Navbar';
import Sidebar from './Sidebar/Sidebar';
import Products from './Products/Products';
import { Outlet } from 'react-router-dom';


const AdminLayout = () => {
    return (
        <>
            <Navbar />
            <Sidebar />
            <div>
                <Outlet />
            </div>

        </>
    );
};

export default AdminLayout;

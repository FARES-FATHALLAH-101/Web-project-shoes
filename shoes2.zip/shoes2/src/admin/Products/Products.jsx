import { Link } from "react-router-dom";
import { IconButton } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import axios from "axios";
import { useEffect, useState } from "react";

const columns = [
    { field: "id", headerName: "Id", width: 90 },
    {
        field: "images",
        headerName: "Images",
        width: 130,
        renderCell: (params) => {
            const imagePaths = params.value ? params.value.split("/") : [];
            const firstImagePath = imagePaths[0];
            const imageUrl = `http://127.0.0.1:8000/storage/product/image/${firstImagePath}`;

            return (
                <div>
                    <img
                        src={imageUrl}
                        alt="Product"
                        style={{ width: "100%", marginBottom: "5px" }}
                    />
                </div>
            );
        },
    },

    { field: "name", headerName: "Name", width: 130 },
    { field: "price", headerName: "Price", width: 100 },
    { field: "description", headerName: "Description", width: 120 },
    {
        field: "category",
        headerName: "Category",
        width: 100,
        valueGetter: (params) => params.row.category.name,
    },
    {
        field: "colors",
        headerName: "Colors",
        sortable: false,
        width: 100,
        renderCell: (params) => {
            const colors = params.value.map((color) => color.color);
            return colors.join(", ");
        },

    },
    {
        field: "sizes",
        headerName: "Sizes",
        sortable: false,
        width: 100,
        renderCell: (params) => {
            const sizes = params.value.map((size) => size.size);
            return sizes.join(", ");
        },


    },
    {
        field: "",
        headerName: "Action",
        sortable: false,
        width: 130,
        renderCell: (params) => (
            <>
                <Link to={`/admin/product/edit/${params.row.id}`}>
                    <IconButton style={{ color: "blue" }}>
                        <EditIcon />
                    </IconButton>
                </Link>
                <IconButton style={{ color: "red" }} >
                    <DeleteIcon />
                </IconButton>
            </>
        ),
    },
];

export default function Products() {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get("http://127.0.0.1:8000/api/products");
                const data = response.data;

                if (response.status === 200) {
                    setProducts(data);
                    console.log(data.images);
                } else {
                    console.log(data);
                }
            } catch (error) {
                console.error(error);
            }
        };

        fetchProducts();
    }, []);

    const deleteProduct = async (productId) => {
        try {
            await axios.delete(`http://127.0.0.1:8000/api/products/${productId}`);
            setProducts(products.filter((product) => product.id !== productId));
            console.log("Product deleted successfully.");
        } catch (error) {
            console.error("Error deleting product:", error);
        }
    };


    return (
        <div className="dashboard">
            <div className="row">
                <div className="col">
                    <nav aria-label="breadcrumb ">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <Link className="text-decoration-none" to="/admin">
                                    Dashboard
                                </Link>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">
                                Products
                            </li>
                        </ol>
                    </nav>
                </div>
                <div className="col">
                    <div className="text-end">
                        <h5>
                            <Link className="text-decoration-none" to="/admin/product/add">
                                New Product
                            </Link>
                        </h5>
                    </div>
                </div>
            </div>
            <div style={{ height: 400, width: "100%" }}>
                <DataGrid
                    rows={products}
                    columns={columns}
                    pageSize={7}
                    checkboxSelection
                    disableSelectionOnClick
                />
            </div>
        </div>
    );
}

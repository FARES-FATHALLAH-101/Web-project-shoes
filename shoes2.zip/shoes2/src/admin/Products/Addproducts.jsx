import React, { useState } from "react";
import { Link, useNavigate } from 'react-router-dom';
import { Button, Chip, MenuItem, TextField } from "@mui/material";
import axios from 'axios';

const categories = ['Category 1', 'Category 2', 'Category 3'];

export default function AddProduct() {
    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');
    const [quantity, setQuantity] = useState('');
    const [discount, setDiscount] = useState('');
    const [color, setColor] = useState('');
    const [sizes, setSizes] = useState('');
    const [images, setImages] = useState([]);

    const navigate = useNavigate()

    const handleSubmit = async (event) => {
        event.preventDefault();
        const formData = new FormData();
        formData.append('name', name);
        formData.append('price', price);
        formData.append('description', description);
        formData.append('quantity', quantity);
        formData.append('discount', discount);
        formData.append('color', color);
        formData.append('sizes', sizes);

        for (let i = 0; i < images.length; i++) {
            formData.append('images[]', images[i]);
        }

        try {
            const response = await fetch('http://127.0.0.1:8000/api/products', {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                const data = await response.json();
                console.log(data);
                navigate('/admin/products')
            } else {
                const errorData = await response.json();
                console.log(errorData);
            }
        } catch (error) {
            console.error(error);
        }

    }


    return (
        <div className="dashboard">
            <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to="/admin">Dashboard</Link></li>
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to="/admin/products">Products</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">New Product</li>
                </ol>
            </nav>
            {/* Form */}
            <form onSubmit={handleSubmit}>
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group pt-3">
                            <TextField fullWidth id="title" label="Title" onChange={(e) => setName(e.target.value)} value={name} variant="standard" name="name" required />
                        </div>
                        <div className="form-group pt-3">
                            <TextField fullWidth id="price" label="Price" onChange={(e) => setPrice(e.target.value)} value={price} variant="standard" name="price" required />
                        </div>
                        <div className="form-group pt-3">
                            <TextField fullWidth id="size" label="Sizes" onChange={(e) => setSizes(e.target.value)} value={sizes} variant="standard" name="sizes" required />
                        </div>
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="description"
                                label="Description"
                                multiline
                                rows={4}
                                onChange={(e) => setDescription(e.target.value)}
                                name="description"
                                value={description}
                                variant="standard"
                                required
                            />
                        </div>
                    </div>
                    <div className="col-md-6 ">
                        {/* <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="categories"
                                select
                                label="Categories"
                                defaultValue="Category 1"
                                value={categories} variant="standard"
                                onChange={(e) => setCate(e.target.value)}
                                name="categories"

                            >
                                {categories.map((option) => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </div> */}
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="color"
                                label="Color"
                                value={color} variant="standard"
                                onChange={(e) => setColor(e.target.value)}
                                name="color"
                                required
                            />
                        </div>
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="quantity"
                                label="Quantity"
                                value={quantity} variant="standard"
                                onChange={(e) => setQuantity(e.target.value)}
                                name="quantity"
                                required
                            />
                        </div>
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="discount"
                                label="Discount"
                                value={discount} variant="standard"
                                onChange={(e) => setDiscount(e.target.value)}
                                name="discount"
                            />
                        </div>
                        <div className="form-group pt-3">
                            {/* <TextField
                                fullWidth
                                id="images"
                                label="Images"
                                variant="standard"
                                onChange={handleImageChange}
                                name="images"
                                type="file"
                                multiple // Allow multiple file selection
                                required
                            /> */}
                            <input type="file" id="images" name="images" onChange={(e) => setImages(e.target.files)} multiple></input>
                        </div>
                    </div>
                </div>
                <div className="text-right mt-3">
                    <button type="submit" className="btn btn-primary">Save changes</button>&nbsp;
                </div>
            </form>
        </div>
    )
};

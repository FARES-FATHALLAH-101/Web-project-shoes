import React, { useState, useRef } from "react";
import { Link } from 'react-router-dom';
import img from '../assets/img/7.jpg'

import { Chip, MenuItem, TextField } from "@mui/material";


const categories = [
    'Category 1',
    'Category 2',
    'Category 3',

];
export default function EditProduct() {
    // Color
    const [tags, setTags] = useState([]);
    const [inputValue, setInputValue] = useState('');

    const handleAddTag = () => {
        if (inputValue.trim() !== '') {
            setTags([...tags, inputValue.trim()]);
            setInputValue('');
        }
    };

    const handleDeleteTag = (tagToDelete) => {
        const updatedTags = tags.filter((tag) => tag !== tagToDelete);
        setTags(updatedTags);
    };
    // Image Upload
    const [selectedDivIndex, setSelectedDivIndex] = useState(null);
    const [images, setImages] = useState([]);

    const handleDivClick = (index) => {
        setSelectedDivIndex(index);
        const fileInput = document.getElementById(`imageInput${index}`);
        fileInput.click();
    };

    const handleImageChange = (event, index) => {
        const file = event.target.files[0];
        const imageUrl = URL.createObjectURL(file);
        const newImages = [...images];
        newImages[index] = imageUrl;
        setImages(newImages);
    };

    const handleFileChange = (event) => {
        const index = selectedDivIndex;
        handleImageChange(event, index);
        setSelectedDivIndex(null);
    };


    return (
        <div className="dashboard">
            <nav aria-label="breadcrumb ">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin'>Dashboard</Link></li>
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin/products'>Products</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">Edit  Product</li>
                </ol>
            </nav>
            {/* Form */}
            <form action="">

                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group pt-3">
                            <TextField fullWidth id="title" label="Title" variant="standard" />
                        </div>
                        <div className="form-group pt-3">
                            <TextField fullWidth id="price" label="Price" variant="standard" />
                        </div>
                        <div className="form-group pt-3">
                            <TextField fullWidth id="size" label="Sizes" variant="standard" />
                        </div>
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="description"
                                label="Description"
                                multiline
                                rows={4}
                                variant="standard"
                            />

                        </div>
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                id="categories"
                                select
                                label="Categories"
                                defaultValue="Category 1"
                                variant="standard"
                            >
                                {categories.map((option) => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                ))}
                            </TextField>

                        </div>
                        <div className="form-group pt-3">
                            <TextField
                                fullWidth
                                label="Color"
                                variant="standard"
                                value={inputValue}
                                onChange={(e) => setInputValue(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        handleAddTag();
                                        e.preventDefault();
                                    }
                                }}
                                InputProps={{
                                    startAdornment: tags.map((tag, index) => (
                                        <Chip
                                            key={index}
                                            label={tag}
                                            onDelete={() => handleDeleteTag(tag)}
                                            style={{
                                                backgroundColor: tag,
                                                margin: '2px',
                                                borderRadius: '4px',
                                            }}
                                        />
                                    )),
                                }}
                                style={{ marginBottom: '8px' }}
                            />
                        </div>

                    </div>

                    <div className="col-md-6 d-flex flex-column align-items-center">
                        <div className="row d-flex justify-content-center pt-3">
                            <div style={{ width: '20pc' }} >
                                <div
                                    style={{
                                        width: '20pc',
                                        height: '20pc',
                                        backgroundColor: '#ccc',
                                        cursor: 'pointer',

                                    }}
                                    onClick={() => handleDivClick(0)}
                                >
                                    {images[0] && <img src={images[0]} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%' }} />}
                                    <input
                                        type="file"
                                        id={`imageInput${0}`}
                                        style={{ display: 'none' }}
                                        accept="image/*"
                                        onChange={handleFileChange}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="row d-flex justify-content-center pt-2">
                            <div className="col">
                                <div
                                    style={{
                                        width: '8pc',
                                        height: '100px',
                                        backgroundColor: '#ccc',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        justifyContent: 'center'
                                    }}
                                    onClick={() => handleDivClick(1)}
                                >
                                    {images[1] && <img src={images[1]} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%' }} />}
                                    <input
                                        type="file"
                                        id={`imageInput${1}`}
                                        style={{ display: 'none' }}
                                        accept="image/*"
                                        onChange={handleFileChange}
                                    />
                                </div>
                            </div>
                            <div className="col">
                                <div
                                    style={{
                                        width: '8pc',
                                        height: '100px',
                                        backgroundColor: '#ccc',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        justifyContent: 'center'
                                    }}
                                    onClick={() => handleDivClick(2)}
                                >
                                    {images[2] && <img src={images[2]} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%' }} />}
                                    <input
                                        type="file"
                                        id={`imageInput${2}`}
                                        style={{ display: 'none' }}
                                        accept="image/*"
                                        onChange={handleFileChange}
                                    />
                                </div>
                            </div>
                            <div className="col">
                                <div
                                    style={{
                                        width: '8pc',
                                        height: '100px',
                                        backgroundColor: '#ccc',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        justifyContent: 'center'
                                    }}
                                    onClick={() => handleDivClick(3)}
                                >
                                    {images[3] && <img src={images[3]} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%' }} />}
                                    <input
                                        type="file"
                                        id={`imageInput${3}`}
                                        style={{ display: 'none' }}
                                        accept="image/*"
                                        onChange={handleFileChange}
                                    />
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="text-right mt-3">
                    <button type="button" className="btn btn-primary">Save changes</button>&nbsp;
                </div>
            </form>
        </div>
    );
};

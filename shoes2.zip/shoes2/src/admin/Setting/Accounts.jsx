import { IconButton } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';

const columns = [
    { field: 'id', headerName: 'Id', width: 90 },
    { field: 'image', headerName: 'Image', width: 160 },
    { field: 'firstName', headerName: 'First Name', width: 140 },
    { field: 'lastName', headerName: 'Last Name', width: 140 },
    { field: 'email', headerName: 'Email', width: 250 },
    { field: 'phone', headerName: 'Phone', width: 160 },
    {
        field: '',
        headerName: 'Action',
        sortable: false,
        width: 120,
        renderCell: (params) => (
            <>
                <Link to={`/admin/account/edit`}>
                    <IconButton style={{ color: 'blue' }}>
                        <EditIcon />
                    </IconButton>
                </Link>
                <IconButton style={{ color: 'red' }}>
                    <DeleteIcon />
                </IconButton>
            </>
        ),
    },
];

const Data = [
    {
        id: 1,
        image: 'png',
        firstName: 'John',
        lastName: 'Doe',
        email: 'johndoe@example.com',
        phone: '1234567890'
    },
    {
        id: 2,
        image: 'png',
        firstName: 'Jane',
        lastName: 'Smith',
        email: 'janesmith@example.com',
        phone: '0987654321'
    },
    {
        id: 3,
        image: 'png',
        firstName: 'David',
        lastName: 'Johnson',
        email: 'davidjohnson@example.com',
        phone: '9876543210'
    },
    {
        id: 4,
        image: 'png',
        firstName: 'Sarah',
        lastName: 'Williams',
        email: 'sarahwilliams@example.com',
        phone: '0123456789'
    },
];
export default function Accounts() {
    return (
        <div className="dashboard">
            <div className="row">
                <div className="col">
                    <nav aria-label="breadcrumb ">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin'>Dashboard</Link></li>
                            <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin/account'>Account</Link></li>
                            <li className="breadcrumb-item active" aria-current="page">Manager Accounts</li>
                        </ol>
                    </nav>
                </div>
                <div className="col">
                    <div className="text-end">
                        <h5>
                            <Link className="text-decoration-none" to='/admin/account/add'>New Account</Link>
                        </h5>
                    </div>
                </div>
            </div>
            <div sx={{ height: 400, width: '100%' }}>
                <DataGrid
                    rows={Data}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 7,
                            },
                        },
                    }}
                    pageSizeOptions={[10]}
                />
            </div>

        </div>

    )
}
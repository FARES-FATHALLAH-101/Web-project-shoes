import React, { useState, useRef } from "react";
import '../Dashboard/style.css'
import upload from '../assets/img/Upload.png'
import { Link } from "react-router-dom";
import { TextField, IconButton, InputAdornment } from "@mui/material";
import { Visibility, VisibilityOff } from '@mui/icons-material';
export default function EditAdmin() {
    const [image, setImage] = useState(null);
    const hiddenFileInput = useRef(null);

    const handleImageChange = (event) => {
        const file = event.target.files[0];
        const imgname = event.target.files[0].name;
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onloadend = () => {
            const img = new Image();
            img.src = reader.result;
            img.onload = () => {
                const canvas = document.createElement("canvas");
                const maxSize = Math.max(img.width, img.height);
                canvas.width = maxSize;
                canvas.height = maxSize;
                const ctx = canvas.getContext("2d");
                ctx.drawImage(
                    img,
                    (maxSize - img.width) / 2,
                    (maxSize - img.height) / 2
                );
                canvas.toBlob(
                    (blob) => {
                        const file = new File([blob], imgname, {
                            type: "image/png",
                            lastModified: Date.now(),
                        });

                        console.log(file);
                        setImage(file);
                    },
                    "image/jpeg",
                    0.8
                );
            };
        };
    };
    const handleClick = (event) => {
        hiddenFileInput.current.click();
    };

    const [showCpassword, setShowCpassword] = useState(false);

    const handleToggleCpassword = () => {
        setShowCpassword(!showCpassword);
    };
    const [showPassword, setShowPassword] = useState(false);

    const handleTogglePassword = () => {
        setShowPassword(!showPassword);
    };
    return (
        <div className="dashboard">
            <nav aria-label="breadcrumb ">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin'>Dashboard</Link></li>
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin/account'>Account</Link></li>
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin/account/manager'>Manager Accounts</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">Edit Accounts</li>
                </ol>
            </nav>
            <div className="d-flex justify-content-center align-items-center">
                <div className="col-md-8">
                    <div className="tab-content">
                        {/* Form */}
                        <form action="">
                            <div className="image-upload-container">
                                <div className="box-decoration">
                                    <div onClick={handleClick} style={{ cursor: "pointer" }}>
                                        {image ? (
                                            <img src={URL.createObjectURL(image)} alt="upload image" className="img-display-after" />
                                        ) : (
                                            <img src={upload} alt="upload image" className="img-display-before" />
                                        )}
                                        <input
                                            id="image-upload-input"
                                            type="file"
                                            onChange={handleImageChange}
                                            ref={hiddenFileInput}
                                            style={{ display: "none" }}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="card-body">
                                <div className="row">
                                    <div className="col">
                                        <div className="form-group pt-3">
                                            <TextField fullWidth id="fname" label="First Name" variant="standard" />

                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="form-group pt-3">
                                            <TextField fullWidth id="lname" label="Last Name" variant="standard" />

                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col">
                                        <div className="form-group pt-3">
                                            <TextField fullWidth id="email" label="Email" variant="standard" />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="form-group pt-3">
                                            <TextField fullWidth id="phone" label="Phone" variant="standard" />
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col">
                                        <div className="form-group pt-3">
                                            <TextField
                                                fullWidth
                                                id="npassword"
                                                label="New Password"
                                                variant="standard"
                                                type={showCpassword ? 'text' : 'password'}
                                                InputProps={{
                                                    endAdornment: (
                                                        <InputAdornment position="end">
                                                            <IconButton onClick={handleToggleCpassword} edge="end">
                                                                {showCpassword ? <VisibilityOff /> : <Visibility />}
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="form-group pt-3">
                                            <TextField
                                                fullWidth
                                                id="npassword"
                                                label="New Password"
                                                variant="standard"
                                                type={showPassword ? 'text' : 'password'}
                                                InputProps={{
                                                    endAdornment: (
                                                        <InputAdornment position="end">
                                                            <IconButton onClick={handleTogglePassword} edge="end">
                                                                {showPassword ? <VisibilityOff /> : <Visibility />}
                                                            </IconButton>
                                                        </InputAdornment>
                                                    ),
                                                }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="text-right mt-3">
                                <button type="button" className="btn btn-primary">Save changes</button>&nbsp;
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div >

    )
}
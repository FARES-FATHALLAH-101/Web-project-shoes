import { Link } from "react-router-dom";

export default function Password() {
    return (
        <div className="dashboard ">
            <nav aria-label="breadcrumb ">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin'>Dashboard</Link></li>
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin/account'>Account</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">Change Password</li>
                </ol>
            </nav>
            <div className="row d-flex justify-content-center align-items-center">
                <div className="col-md-8">
                    <div className="tab-content">
                        <div className="tab-pane fade active show" id="account-general">
                            <hr className="border-light m-0" />
                            <div className="card-body">
                                <div className="form-group pt-3">
                                    <label className="form-label">Current password</label>
                                    <input type="password" className="form-control mb-1" />
                                </div>
                                <div className="form-group pt-3">
                                    <label className="form-label">New password</label>
                                    <input type="password" className="form-control" />
                                </div>
                                <div className="form-group pt-3">
                                    <label className="form-label">Repeat new password</label>
                                    <input type="password" className="form-control mb-1" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="text-right mt-3">
                <button type="button" className="btn btn-primary">Save changes</button>&nbsp;
            </div>

        </div>

    )
}
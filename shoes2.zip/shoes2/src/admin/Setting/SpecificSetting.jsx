import { TextField } from "@mui/material";
import { Link } from "react-router-dom";

export default function SpecificSetting() {
    return (
        <div className="dashboard">
            <nav aria-label="breadcrumb ">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin'>Dashboard</Link></li>
                    <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin/account'>Account</Link></li>
                    <li className="breadcrumb-item active" aria-current="page">Social media</li>
                </ol>
            </nav>
            <div className="row mb-2 gx-5">
                <div className="col-xxl-6 mb-5 mb-xxl-0">
                    <div className="bg-secondary-soft px-4 py-2 rounded">
                        <form action="">
                            <div className="row g-3">
                                {/* Facebook */}
                                <div className="col-md-6">
                                    <TextField id="facebook" fullWidth label="Facebook" variant="outlined" />
                                </div>
                                {/* Twitter */}
                                <div className="col-md-6">
                                    <TextField id="twitter" fullWidth label="Twitter" variant="outlined" />
                                </div>
                                {/* Instragram */}
                                <div className="col-md-6">
                                    <TextField id="instragram" fullWidth label="Instragram" variant="outlined" />
                                </div>
                                <div className="text-right mt-3">
                                    <button type="button" className="btn btn-primary">Save changes</button>&nbsp;
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div >

    )
}
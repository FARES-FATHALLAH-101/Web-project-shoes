import React, { useEffect, useState } from 'react';
import AddCategory from './Addcategory';
import Editcategory from './Editcategory';
import { IconButton } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { Link } from 'react-router-dom';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';

export default function Categories() {
    const [data, setData] = useState([]);
    const [showAddForm, setShowAddForm] = useState(false);
    const [selectedCategoryId, setSelectedCategoryId] = useState(null);

    const fetchData = async () => {
        try {
            const res = await axios.get('http://localhost:8000/api/categoryAffich');
            setData(res.data.data);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleShowAddForm = () => {
        setShowAddForm(true);
        document.body.style.overflow = 'hidden';
    };

    const handleCloseForm = () => {
        setShowAddForm(false);
        setSelectedCategoryId(null);
        document.body.style.overflow = 'auto';
    };

    const handleEdit = (categoryId) => {
        setSelectedCategoryId(categoryId);
        setShowAddForm(true);
        document.body.style.overflow = 'hidden';
    };

    const handleDelete = async (categoryId) => {
        try {
            await axios.delete(`http://localhost:8000/api/categoryDel/${categoryId}`);
            fetchData();
        } catch (error) {
            console.log(error);
        }
    };

    const columns = [
        { field: 'id', headerName: 'Id', width: 90 },
        { field: 'name', headerName: 'Name', width: 200 },
        { field: 'created_at', headerName: 'created_at', width: 200 },
        { field: 'updated_at', headerName: 'updated_at', width: 200 },
        {
            field: '',
            headerName: 'Action',
            sortable: false,
            width: 160,
            renderCell: (params) => (
                <>
                    <IconButton onClick={() => handleEdit(params.row.id)} style={{ color: 'blue' }}>
                        <EditIcon />
                    </IconButton>
                    <IconButton onClick={() => handleDelete(params.row.id)} style={{ color: 'red' }}>
                        <DeleteIcon />
                    </IconButton>
                </>
            ),
        },
    ];

    return (
        <div className="dashboard">
            <div className="row">
                <div className="col">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <Link className="text-decoration-none" to="/admin">
                                    Dashboard
                                </Link>
                            </li>
                            <li className="breadcrumb-item">
                                <Link className="text-decoration-none" to="/admin/product">
                                    Products
                                </Link>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">
                                Category
                            </li>
                        </ol>
                    </nav>
                </div>
                <div className="col">
                    <div className="text-end">
                        <h5 onClick={handleShowAddForm} style={{ cursor: 'pointer' }}>
                            New Category
                        </h5>
                    </div>
                </div>
            </div>
            <div style={{ height: 400, width: '100%' }}>
                <DataGrid rows={data} columns={columns} pagination pageSize={7} pageSizeOptions={[10]} />
            </div>
            {showAddForm && (
                <div className="overlay-form">
                    {selectedCategoryId ? (
                        <Editcategory categoryId={selectedCategoryId} onCloseForm={handleCloseForm} onUpdate={fetchData} />
                    ) : (
                        <AddCategory onCloseForm={handleCloseForm} onAdd={fetchData} />
                    )}
                </div>
            )}
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function EditCategory({ categoryId, onUpdate, onCloseForm }) {
  const [name, setName] = useState('');
  const handleCloseForm = () => {
    onCloseForm();
    document.body.style.overflow = 'auto';
};
  useEffect(() => {
    const fetchCategory = async () => {
      try {
        const res = await axios.get(`http://localhost:8000/api/category/edit/${categoryId}`);
        setName(res.data.name);
      } catch (error) {
        console.log(error);
      }
    };

    fetchCategory();
  }, [categoryId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:8000/api/category/update/${categoryId}`, { name });
      onUpdate();
      onCloseForm();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="dashboard">
    <div class="d-flex flex-wrap justify-content-center align-items-center" style={{}}>
        <form onSubmit={handleSubmit} class="bg-light p-3 rounded">
            <div className='text-end'>
                <i style={{cursor:'pointer'}} class="bi bi-x-circle-fill fs-5 text-danger" onClick={handleCloseForm}></i>
            </div>
            <div class="form-group">
                <label for="name" class="control-label">Name Category</label>
                <input type="text" class="form-control form-control-addproduct" name="name" id="name" placeholder="Name Category" value={name} onChange={(e) => setName(e.target.value)}/>
            </div>
            <hr />
            <div class="form-group">
            <button type="submit" className="btn btn-primary">Save</button>&nbsp;
            </div>
        </form>
    </div>

</div>
  );
}

import React, { useRef } from 'react';
import '../Dashboard/style.css'
import axios from 'axios';
export default function AddCategory({ onCloseForm }) {
    const handleCloseForm = () => {
        onCloseForm();
        document.body.style.overflow = 'auto';
    };


    const categoryRef = useRef();

    const handleSubmit = (event) => {
        event.preventDefault();
        const category = categoryRef.current.value;
        const formData = {
            category,
        };


        axios.post('http://127.0.0.1:8000/api/category', formData)
            .then((response) => {
                event.target.reset();
                onCloseForm();
                document.body.style.overflow = 'auto';
            })
            .catch((error) => {
                console.error(error);
            });
    };
    return (
        <div className="dashboard">
            <div class="d-flex flex-wrap justify-content-center align-items-center" style={{}}>
                <form onSubmit={handleSubmit} class="bg-light p-3 rounded">
                    <div className='text-end'>
                        <i style={{ cursor: 'pointer' }} class="bi bi-x-circle-fill fs-5 text-danger" onClick={handleCloseForm}></i>
                    </div>
                    <div class="form-group">
                        <label for="name" class="control-label">Name Category</label>
                        <input type="text" class="form-control form-control-addproduct" name="category" id="name" placeholder="Name Category" ref={categoryRef} required />
                    </div>
                    <hr />
                    <div class="form-group">
                        <button type="submit" className="btn btn-primary">Save</button>&nbsp;
                    </div>
                </form>
            </div>

        </div>
    )
}
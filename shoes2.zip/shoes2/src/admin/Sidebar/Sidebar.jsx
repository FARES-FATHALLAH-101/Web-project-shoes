import React from 'react';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './app.css';
import { Link } from 'react-router-dom';
import { useState } from 'react';

function Sidebar() {
    const [collapseOpen, setCollapseOpen] = useState(false);

    const toggleCollapse = () => {
        setCollapseOpen(!collapseOpen);
    };
    const [collapseOpen2, setCollapseOpen2] = useState(false);

    const toggleCollapse2 = () => {
        setCollapseOpen2(!collapseOpen2);
    };
    return (
        <div className="offcanvas offcanvas-start sidebar-nav bg-dark" tabIndex="-1" id="sidebar">
            <div className="offcanvas-body p-0">
                <nav className="navbar-dark">
                    <ul className="navbar-nav">
                        <li>
                            <Link to='/admin' className="nav-link px-3 active">
                                <span className="me-2"><i className="bi bi-speedometer2 fs-5 me-3"></i></span>
                                <span>Dashboard</span>
                            </Link>
                        </li>
                        <li>
                            <Link to="/admin/products" className="nav-link px-3 active sidebar-link" >
                                <span className="me-2"><i className='bi bi-basket fs-5 me-3'></i></span>
                                <span>Products</span>
                            <span className="ms-auto" onClick={toggleCollapse}>
                                <span className="right-icon">
                                    <i className={`bi bi-chevron-${collapseOpen ? 'up' : 'down'}`}></i>
                                </span>
                            </span>
                            </Link>

                            <div className={`collapse${collapseOpen ? ' show' : ''}`} id="layouts">
                                <ul className="navbar-nav ps-3">
                                    <li>
                                        <Link to="/admin/product/add" className="nav-link px-3">
                                            <span className="me-2"><i className="bi bi-palette-fill"></i></span>
                                            <span>Add Product</span>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="/admin/categories" className="nav-link px-3">
                                            <span className="me-2"><i className="bi bi-tags"></i></span>
                                            <span>Categories</span>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li>
                            <Link to='/admin/order' className="nav-link px-3 active">
                                <span className="me-2"><i className="bi bi-cart-check-fill fs-5 me-3"></i></span>
                                <span>Orders</span>
                            </Link>
                        </li>
                        <li>
                            <Link className="nav-link px-3 active sidebar-link" >
                                <span className="me-2"><i className="bi bi-gear fs-5 me-3"></i></span>
                                <span>Setting App</span>
                                <span className="ms-auto">
                                    <span className="right-icon" onClick={toggleCollapse2}>
                                        <i className={`bi bi-chevron-${collapseOpen2 ? 'up' : 'down'}`}></i>
                                    </span>
                                </span>
                            </Link>
                            <div className={`collapse${collapseOpen2 ? ' show' : ''}`} id="layouts">
                                <ul className="navbar-nav ps-3">
                                    <li>
                                        <Link to="/admin/account" className="nav-link px-3">
                                            <span className="me-2"><i className="bi bi-person-vcard-fill"></i></span>
                                            <span>Personal information</span>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="/admin/account/password" className="nav-link px-3">
                                            <span className="me-2"><i className="bi bi-person-vcard-fill"></i></span>
                                            <span>Change Password</span>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="/admin/account/manager" className="nav-link px-3">
                                            <span className="me-2"><i className="bi bi-person-vcard-fill"></i></span>
                                            <span>Manager Admin</span>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to="/admin/specific-setting" className="nav-link px-3">
                                            <span className="me-2"><i className="bi bi-sliders"></i></span>
                                            <span>Specific Settings</span>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </li>


                    </ul>
                </nav>
            </div>
        </div>
    );
}

export default Sidebar;

import { IconButton } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { Link } from "react-router-dom";
import DeleteIcon from '@mui/icons-material/Delete';
const testData = [
    {
      id: '1', // Add unique id property
      orderID: '1',
      clientName: 'John Doe',
      productName: 'Product A',
      address: '123 Main St',
      date: '2023-06-01',
      price: '$100',
      paymentType: 'Credit Card',
      status: 'Completed',
    },
    {
      id: '2', // Add unique id property
      orderID: '2',
      clientName: 'Jane Smith',
      productName: 'Product B',
      address: '456 Elm St',
      date: '2023-06-02',
      price: '$80',
      paymentType: 'PayPal',
      status: 'Pending',
    },
    // Add more test data objects here...
  ];
  

const columns = [
    { field: 'orderID', headerName: 'Order ID', width: 90 },
    { field: 'clientName', headerName: 'Client Name', width: 170, sortable: false },
    { field: 'productName', headerName: 'Product Name', width: 130 },
    { field: 'address', headerName: 'Address', width: 100 },
    { field: 'date', headerName: 'Date', width: 120 },
    { field: 'price', headerName: 'Price', width: 100 },
    { field: 'paymentType', headerName: 'Payment Type', width: 130 },
    { field: 'status', headerName: 'Status', width: 100 },
    {
        field: 'actions',
        headerName: 'Action',
        sortable: false,
        width: 100,
        renderCell: (params) => (
            <>
                <IconButton style={{ color: 'red' }}>
                    <DeleteIcon />
                </IconButton>
            </>
        ),
    },
];

export default function Orders() {
    return (
        <div className="dashboard">
            <div className="row">
                <div className="col">
                    <nav aria-label="breadcrumb ">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link className="text-decoration-none" to='/admin'>Dashboard</Link></li>
                            <li className="breadcrumb-item active" aria-current="page">Orders</li>
                        </ol>
                    </nav>
                </div>

            </div>
            <div sx={{ height: 400, width: '100%' }}>
                <DataGrid
                    rows={testData}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 7,
                            },
                        },
                    }}
                    pageSizeOptions={[10]}
                />
            </div>
        </div >
    )
}